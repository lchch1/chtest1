package com.example.yamnetwatchapp0913

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale
import android.view.View
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken


class ChatActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var recyclerView: RecyclerView
    private lateinit var etMessage: EditText
    private lateinit var btnSend: Button
    private lateinit var btnSpeak: Button
    private lateinit var btnRecordVoice: Button
    private lateinit var btnBack: ImageView
    private lateinit var btnSave: Button
    private lateinit var btnList: Button
    private lateinit var btnUnderstand: Button
    private lateinit var guidanceOverlay: FrameLayout

    private var guidanceTTS: TextToSpeech? = null

    private lateinit var chatAdapter: ChatAdapter
    private val messageList = mutableListOf<ChatMessage>()

    private lateinit var textToSpeech: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var speechIntent: Intent

    private var isRecording = false
    private var lastMyMessage: String = ""
    private var isTTSInitialized = false

    // [P2 수정] Gson 인스턴스 추가
    private val gson = Gson()

    companion object {
        private const val PERMISSION_REQUEST_CODE = 100
        private const val TAG = "ChatActivity_DEBUG"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        checkAndRequestPermissions()
        initializeViews()
        setupDiagnosticButtons()

        guidanceOverlay = findViewById(R.id.guidanceOverlay)
        btnUnderstand = findViewById(R.id.btnUnderstand)

        initGuidanceTTS()

        if (guidanceOverlay.visibility == View.VISIBLE) {
            playGuidanceTTS()
        }

        btnUnderstand.setOnClickListener {
            guidanceOverlay.visibility = View.GONE
            guidanceTTS?.stop()
        }

        MainActivity.mainActivityInstance?.stopDoorbellDetection()

        initTextToSpeech()
        initializeSpeechIntent()
        setupRecyclerView()
        setupButtonListeners()
    }

    private fun initGuidanceTTS() {
        guidanceTTS = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val langResult = guidanceTTS?.setLanguage(Locale.KOREAN)
                if (langResult != TextToSpeech.LANG_MISSING_DATA && langResult != TextToSpeech.LANG_NOT_SUPPORTED) {
                    playGuidanceTTS()
                }
            }
        }
    }

    private fun playGuidanceTTS() {
        val guidanceText = "저는 청각장애인입니다. 제가 소리를 들을 수 없는 상황이라 여기서 저와 대화해주시면 감사드리겠습니다."
        guidanceTTS?.let { tts ->
            if (tts.isSpeaking) tts.stop()
            tts.setPitch(1.0f)
            tts.setSpeechRate(1.0f)
            tts.speak(guidanceText, TextToSpeech.QUEUE_FLUSH, null, "guidanceID")
        }
    }

    private fun initializeViews() {
        btnBack = findViewById(R.id.btnBack)
        guidanceOverlay = findViewById(R.id.guidanceOverlay)
        btnUnderstand = findViewById(R.id.btnUnderstand)
        recyclerView = findViewById(R.id.recyclerView)
        etMessage = findViewById(R.id.etMessage)
        btnSend = findViewById(R.id.btnSend)
        btnSpeak = findViewById(R.id.btnSpeak)
        btnRecordVoice = findViewById(R.id.btnRecordVoice)
        btnSave = findViewById(R.id.btnSave)
        btnList = findViewById(R.id.btnList)
    }

    private fun setupRecyclerView() {
        chatAdapter = ChatAdapter(messageList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = chatAdapter
    }

    private fun setupButtonListeners() {
        btnBack.setOnClickListener {
            MainActivity.mainActivityInstance?.startDoorbellDetection()
            finish()
        }
        btnUnderstand.setOnClickListener { guidanceOverlay.visibility = View.GONE }
        btnSend.setOnClickListener { sendMessage() }
        btnSpeak.setOnClickListener { replayMessage() }
        btnRecordVoice.setOnClickListener { toggleVoiceRecording() }
        btnSave.setOnClickListener { showSaveDialog() }
        btnList.setOnClickListener { startActivity(Intent(this, ConversationListActivity::class.java)) }
    }

    private fun setupDiagnosticButtons() {
        btnSpeak.setOnLongClickListener { showDiagnosticDialog(); true }
        btnRecordVoice.setOnLongClickListener { showDiagnosticDialog(); true }
    }

    private fun showDiagnosticDialog() {
        AlertDialog.Builder(this)
            .setTitle("진단 메뉴")
            .setMessage("TTS 초기화: $isTTSInitialized\n음성 인식 가능: ${SpeechRecognizer.isRecognitionAvailable(this)}")
            .setPositiveButton("TTS 테스트") { _, _ -> testTTS() }
            .setNegativeButton("STT 테스트") { _, _ -> testSTT() }
            .setNeutralButton("닫기", null)
            .show()
    }

    private fun testTTS() {
        if (isTTSInitialized) textToSpeech.speak("테스트입니다", TextToSpeech.QUEUE_FLUSH, null, null)
    }

    private fun testSTT() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(testSpeechListener)
            speechRecognizer?.startListening(speechIntent)
        }
    }

    private val testSpeechListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) { Log.e(TAG, "STT 에러: $error") }
        override fun onResults(results: Bundle) { Log.d(TAG, "STT 결과: ${results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)}") }
        override fun onPartialResults(partialResults: Bundle) {}
        override fun onEvent(eventType: Int, params: Bundle) {}
    }

    private fun sendMessage() {
        val messageText = etMessage.text.toString().trim()
        if (messageText.isNotEmpty()) {
            chatAdapter.addMessage(ChatMessage(messageText, isMine = true))
            lastMyMessage = messageText
            etMessage.text.clear()
            recyclerView.scrollToPosition(messageList.size - 1)
            if (isTTSInitialized) playTTS(messageText)
        }
    }

    private fun replayMessage() {
        if (lastMyMessage.isNotEmpty() && isTTSInitialized) playTTS(lastMyMessage)
    }

    private fun toggleVoiceRecording() {
        if (!isRecording) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                checkAndRequestPermissions(); return
            }
            if (SpeechRecognizer.isRecognitionAvailable(this)) {
                startSpeech()
                btnRecordVoice.text = "⏹"
                btnRecordVoice.alpha = 0.7f
                isRecording = true
            }
        } else {
            stopSpeech()
            btnRecordVoice.text = "🎤"
            btnRecordVoice.alpha = 1.0f
            isRecording = false
        }
    }

    private fun initTextToSpeech() {
        textToSpeech = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            when (textToSpeech.setLanguage(Locale.KOREAN)) {
                TextToSpeech.LANG_MISSING_DATA -> startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA))
                TextToSpeech.LANG_NOT_SUPPORTED -> { textToSpeech.language = Locale.ENGLISH; isTTSInitialized = true }
                else -> isTTSInitialized = true
            }
        }
    }

    private fun playTTS(text: String) {
        if (!isTTSInitialized) return
        try {
            if (textToSpeech.isSpeaking) textToSpeech.stop()
            textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
        } catch (e: Exception) { Log.e(TAG, "TTS 재생 오류: ${e.message}") }
    }

    private fun initializeSpeechIntent() {
        speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 5000L)
        }
    }

    private fun startSpeech() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(speechListener)
            speechRecognizer?.startListening(speechIntent)
        } catch (e: Exception) {
            Log.e(TAG, "음성 인식 시작 실패: ${e.message}", e)
            resetRecordButton()
        }
    }

    private fun stopSpeech() {
        try { speechRecognizer?.stopListening() }
        catch (e: Exception) { Log.e(TAG, "음성 인식 중지 오류: ${e.message}") }
    }

    private val speechListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) { Log.e(TAG, "STT 에러: $error"); resetRecordButton() }
        override fun onResults(results: Bundle) {
            val list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (!list.isNullOrEmpty()) {
                runOnUiThread {
                    chatAdapter.addMessage(ChatMessage(list[0], isMine = false))
                    recyclerView.scrollToPosition(messageList.size - 1)
                }
            }
            resetRecordButton()
        }
        override fun onPartialResults(partialResults: Bundle) {}
        override fun onEvent(eventType: Int, params: Bundle) {}
    }

    private fun resetRecordButton() {
        runOnUiThread {
            btnRecordVoice.text = "🎤"
            btnRecordVoice.alpha = 1.0f
            isRecording = false
        }
    }

    private fun showSaveDialog() {
        val editText = EditText(this).apply { hint = "대화 제목을 입력하세요"; setPadding(40, 20, 40, 20) }

        AlertDialog.Builder(this)
            .setTitle("대화 저장")
            .setView(editText)
            .setPositiveButton("저장") { _, _ ->
                val title = editText.text.toString().trim()
                if (title.isNotEmpty()) saveConversation(title)
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun saveConversation(title: String) {
        val sharedPref = getSharedPreferences("conversations", MODE_PRIVATE)
        val recordId = System.currentTimeMillis()
        // [P2 수정] 수동 JSON 빌더 → Gson (특수문자 안전 처리)
        val messagesJson = gson.toJson(messageList)

        with(sharedPref.edit()) {
            putString("title_$recordId", title)
            putString("messages_$recordId", messagesJson)
            putLong("timestamp_$recordId", recordId)
            apply()
        }
    }

    private fun checkAndRequestPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), PERMISSION_REQUEST_CODE)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    override fun onDestroy() {
        super.onDestroy()
        MainActivity.mainActivityInstance?.startDoorbellDetection()
        if (::textToSpeech.isInitialized) { textToSpeech.stop(); textToSpeech.shutdown() }
        speechRecognizer?.destroy()
        speechRecognizer = null
        guidanceTTS?.stop()
        guidanceTTS?.shutdown()
    }

    override fun onPause() {
        super.onPause()
        if (isRecording) { stopSpeech(); resetRecordButton() }
    }
}
