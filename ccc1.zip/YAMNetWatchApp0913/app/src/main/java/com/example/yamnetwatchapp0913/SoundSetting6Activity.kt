package com.example.yamnetwatchapp0913

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class SoundSetting6Activity : AppCompatActivity() {

    private lateinit var jjinhadanHome: ImageView

    private val switchStates = mutableMapOf(
        R.id.sw1 to true, R.id.sw2 to true, R.id.sw3 to true, R.id.sw4 to true,
        R.id.Ssssssw5 to true, R.id.Ssssssw6 to true,
    )

    override fun onPause() { super.onPause(); saveSwitchStates() }
    override fun onDestroy() { super.onDestroy(); saveSwitchStates() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_soundsetting6)

        loadSwitchStates()
        initializeSwitchUI()
        setupSwitchListeners()

        jjinhadanHome = findViewById(R.id.jjinhadanhome)
        jjinhadanHome.setOnClickListener {
            MainActivity.mainActivityInstance?.startDoorbellDetection()
            finish()
        }
    }

    private fun saveSwitchStates() {
        getSharedPreferences("mymode6_settings", MODE_PRIVATE).edit().apply {
            putBoolean("sw1_state", switchStates[R.id.sw1] ?: true)
            putBoolean("sw2_state", switchStates[R.id.sw2] ?: true)
            putBoolean("sw3_state", switchStates[R.id.sw3] ?: true)
            putBoolean("sw4_state", switchStates[R.id.sw4] ?: true)
            apply()
        }
        getSharedPreferences("dog6_settings", MODE_PRIVATE).edit()
            .putBoolean("Ssssssw6_state", switchStates[R.id.Ssssssw6] ?: true).apply()
        getSharedPreferences("kid6_settings", MODE_PRIVATE).edit()
            .putBoolean("Ssssssw5_state", switchStates[R.id.Ssssssw5] ?: true).apply()
    }

    private fun loadSwitchStates() {
        val p = getSharedPreferences("mymode6_settings", MODE_PRIVATE)
        switchStates[R.id.sw1] = p.getBoolean("sw1_state", true)
        switchStates[R.id.sw2] = p.getBoolean("sw2_state", true)
        switchStates[R.id.sw3] = p.getBoolean("sw3_state", true)
        switchStates[R.id.sw4] = p.getBoolean("sw4_state", true)
        switchStates[R.id.Ssssssw6] = getSharedPreferences("dog6_settings", MODE_PRIVATE).getBoolean("Ssssssw6_state", true)
        switchStates[R.id.Ssssssw5] = getSharedPreferences("kid6_settings", MODE_PRIVATE).getBoolean("Ssssssw5_state", true)
    }

    private fun initializeSwitchUI() {
        listOf(R.id.sw1, R.id.sw2, R.id.sw3, R.id.sw4, R.id.Ssssssw5, R.id.Ssssssw6).forEach { id ->
            updateSwitchImage(findViewById(id), switchStates[id] ?: true)
        }
    }

    private fun setupSwitchListeners() {
        listOf(R.id.sw1, R.id.sw2, R.id.sw3, R.id.sw4, R.id.Ssssssw5, R.id.Ssssssw6).forEach { id ->
            findViewById<ImageView>(id).setOnClickListener { v ->
                val newState = !(switchStates[id] ?: true)
                switchStates[id] = newState
                updateSwitchImage(v as ImageView, newState)
            }
        }
    }

    private fun updateSwitchImage(view: ImageView, isOn: Boolean) {
        view.setImageResource(if (isOn) R.drawable.ssonswitch else R.drawable.ssoffswitch)
    }
}
