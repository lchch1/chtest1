package com.example.yamnetwatchapp0913

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class SoundSetting5Activity : AppCompatActivity() {

    private lateinit var jjinhadanHome: ImageView

    private val switchStates = mutableMapOf(
        R.id.sw1 to true, R.id.sw2 to true, R.id.sw3 to true, R.id.sw4 to true,
        R.id.Sssssw5 to true, R.id.Sssssw6 to true, R.id.Sssssw7 to true
    )

    override fun onPause() { super.onPause(); saveSwitchStates() }
    override fun onDestroy() { super.onDestroy(); saveSwitchStates() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_soundsetting5)

        loadSwitchStates()
        initializeSwitchUI()
        setupSwitchListeners()

        jjinhadanHome = findViewById(R.id.jjinhadanhome)
        jjinhadanHome.setOnClickListener {
            MainActivity.mainActivityInstance?.startDoorbellDetection()
            finish()
        }
    }

    private fun saveSwitchStates() {
        getSharedPreferences("school5_settings", MODE_PRIVATE).edit().apply {
            putBoolean("sw1_state", switchStates[R.id.sw1] ?: true)
            putBoolean("sw2_state", switchStates[R.id.sw2] ?: true)
            putBoolean("sw3_state", switchStates[R.id.sw3] ?: true)
            putBoolean("sw4_state", switchStates[R.id.sw4] ?: true)
            putBoolean("Sssssw7_state", switchStates[R.id.Sssssw7] ?: true)
            apply()
        }
        getSharedPreferences("dog5_settings", MODE_PRIVATE).edit()
            .putBoolean("Sssssw6_state", switchStates[R.id.Sssssw6] ?: true).apply()
        getSharedPreferences("kid5_settings", MODE_PRIVATE).edit()
            .putBoolean("Sssssw5_state", switchStates[R.id.Sssssw5] ?: true).apply()
    }

    private fun loadSwitchStates() {
        val p = getSharedPreferences("school5_settings", MODE_PRIVATE)
        switchStates[R.id.sw1] = p.getBoolean("sw1_state", true)
        switchStates[R.id.sw2] = p.getBoolean("sw2_state", true)
        switchStates[R.id.sw3] = p.getBoolean("sw3_state", true)
        switchStates[R.id.sw4] = p.getBoolean("sw4_state", true)
        switchStates[R.id.Sssssw7] = p.getBoolean("Sssssw7_state", true)
        switchStates[R.id.Sssssw6] = getSharedPreferences("dog5_settings", MODE_PRIVATE).getBoolean("Sssssw6_state", true)
        switchStates[R.id.Sssssw5] = getSharedPreferences("kid5_settings", MODE_PRIVATE).getBoolean("Sssssw5_state", true)
    }

    private fun initializeSwitchUI() {
        listOf(R.id.sw1, R.id.sw2, R.id.sw3, R.id.sw4, R.id.Sssssw5, R.id.Sssssw6, R.id.Sssssw7).forEach { id ->
            updateSwitchImage(findViewById(id), switchStates[id] ?: true)
        }
    }

    private fun setupSwitchListeners() {
        listOf(R.id.sw1, R.id.sw2, R.id.sw3, R.id.sw4, R.id.Sssssw5, R.id.Sssssw6, R.id.Sssssw7).forEach { id ->
            findViewById<ImageView>(id).setOnClickListener { v ->
                val newState = !(switchStates[id] ?: true)
                switchStates[id] = newState
                updateSwitchImage(v as ImageView, newState)
            }
        }
    }

    private fun updateSwitchImage(view: ImageView, isOn: Boolean) {
        view.setImageResource(if (isOn) R.drawable.ssonswitch else R.drawable.ssoffswitch)
    }
}
