package com.example.yamnetwatchapp0913

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class SoundSetting2Activity : AppCompatActivity() {

    private lateinit var jjinhadanHome: ImageView

    private val switchStates = mutableMapOf(
        R.id.sw1 to true, R.id.sw2 to true, R.id.sw3 to true, R.id.sw4 to true,
        R.id.Ssw5 to true, R.id.Ssw6 to true,
    )

    // [P2 수정] onPause, onDestroy 저장 추가
    override fun onPause() { super.onPause(); saveSwitchStates() }
    override fun onDestroy() { super.onDestroy(); saveSwitchStates() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_soundsetting2)

        loadSwitchStates()
        initializeSwitchUI()
        setupSwitchListeners()

        jjinhadanHome = findViewById(R.id.jjinhadanhome)
        jjinhadanHome.setOnClickListener {
            MainActivity.mainActivityInstance?.startDoorbellDetection()
            finish()
        }
    }

    private fun saveSwitchStates() {
        getSharedPreferences("transit2_settings", MODE_PRIVATE).edit().apply {
            putBoolean("sw1_state", switchStates[R.id.sw1] ?: true)
            putBoolean("sw2_state", switchStates[R.id.sw2] ?: true)
            putBoolean("sw3_state", switchStates[R.id.sw3] ?: true)
            putBoolean("sw4_state", switchStates[R.id.sw4] ?: true)
            apply()
        }
        getSharedPreferences("dog2_settings", MODE_PRIVATE).edit()
            .putBoolean("Ssw6_state", switchStates[R.id.Ssw6] ?: true).apply()
        getSharedPreferences("kid2_settings", MODE_PRIVATE).edit()
            .putBoolean("Ssw5_state", switchStates[R.id.Ssw5] ?: true).apply()
    }

    private fun loadSwitchStates() {
        val p = getSharedPreferences("transit2_settings", MODE_PRIVATE)
        switchStates[R.id.sw1] = p.getBoolean("sw1_state", true)
        switchStates[R.id.sw2] = p.getBoolean("sw2_state", true)
        switchStates[R.id.sw3] = p.getBoolean("sw3_state", true)
        switchStates[R.id.sw4] = p.getBoolean("sw4_state", true)
        switchStates[R.id.Ssw6] = getSharedPreferences("dog2_settings", MODE_PRIVATE).getBoolean("Ssw6_state", true)
        switchStates[R.id.Ssw5] = getSharedPreferences("kid2_settings", MODE_PRIVATE).getBoolean("Ssw5_state", true)
    }

    private fun initializeSwitchUI() {
        listOf(R.id.sw1, R.id.sw2, R.id.sw3, R.id.sw4, R.id.Ssw5, R.id.Ssw6).forEach { id ->
            updateSwitchImage(findViewById(id), switchStates[id] ?: true)
        }
    }

    private fun setupSwitchListeners() {
        listOf(R.id.sw1, R.id.sw2, R.id.sw3, R.id.sw4, R.id.Ssw5, R.id.Ssw6).forEach { id ->
            findViewById<ImageView>(id).setOnClickListener { v ->
                val newState = !(switchStates[id] ?: true)
                switchStates[id] = newState
                updateSwitchImage(v as ImageView, newState)
            }
        }
    }

    private fun updateSwitchImage(view: ImageView, isOn: Boolean) {
        view.setImageResource(if (isOn) R.drawable.ssonswitch else R.drawable.ssoffswitch)
    }
}
