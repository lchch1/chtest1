package com.example.yamnetwatchapp0913

data class WordItem(
    val name: String,
    var isOn: Boolean = false
)
