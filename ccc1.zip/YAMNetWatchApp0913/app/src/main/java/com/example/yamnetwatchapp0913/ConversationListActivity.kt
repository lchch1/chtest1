package com.example.yamnetwatchapp0913

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class ConversationListActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var btnBack: ImageView
    private lateinit var conversationAdapter: ConversationAdapter
    private val conversationList = mutableListOf<ConversationRecord>()
    private val gson = Gson()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conversation_list)

        btnBack = findViewById(R.id.btnBack)
        btnBack.setOnClickListener { finish() }

        recyclerView = findViewById(R.id.recyclerView)
        conversationAdapter = ConversationAdapter(conversationList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = conversationAdapter

        loadConversations()
    }

    private fun loadConversations() {
        val sharedPref = getSharedPreferences("conversations", MODE_PRIVATE)
        conversationList.clear()

        val recordIds = mutableSetOf<Long>()
        sharedPref.all.keys.forEach { key ->
            if (key.startsWith("title_")) {
                key.substring(6).toLongOrNull()?.let { recordIds.add(it) }
            }
        }

        recordIds.sortedDescending().forEach { recordId ->
            val title = sharedPref.getString("title_$recordId", "제목 없음") ?: "제목 없음"
            val messagesJson = sharedPref.getString("messages_$recordId", "[]") ?: "[]"
            val timestamp = sharedPref.getLong("timestamp_$recordId", 0L)

            conversationList.add(ConversationRecord(
                id = recordId,
                title = title,
                // [P2 수정] split 파싱 → Gson
                messages = parseMessagesJson(messagesJson),
                timestamp = timestamp
            ))
        }

        conversationAdapter.notifyDataSetChanged()
    }

    private fun parseMessagesJson(json: String): List<ChatMessage> {
        return try {
            val type = object : TypeToken<List<ChatMessage>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }
}
