package com.example.yamnetwatchapp0913

import android.content.Context
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.wear.widget.BoxInsetLayout
import com.google.android.gms.wearable.DataClient
import com.google.android.gms.wearable.DataEvent
import com.google.android.gms.wearable.DataEventBuffer
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.MessageClient
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.Wearable
import java.text.SimpleDateFormat
import java.util.*

// ✅ 전역 인스턴스 관리
object WatchMainActivityHolder {
    var mainActivity: MainActivity? = null
}

class MainActivity : AppCompatActivity(), DataClient.OnDataChangedListener, MessageClient.OnMessageReceivedListener {

    private lateinit var containerView: BoxInsetLayout
    private lateinit var tvSoundStatus: TextView
    private lateinit var tvLastDetection: TextView
    private lateinit var tvTimestamp: TextView

    // ✅ 알림 컴포넌트
    private lateinit var alertContainer: LinearLayout
    private lateinit var alertImageView: ImageView
    private lateinit var alertTextLabel: TextView
    private lateinit var backgroundDimmer: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_wear)

        // ✅ 싱글톤 인스턴스 저장
        WatchMainActivityHolder.mainActivity = this

        containerView    = findViewById(R.id.container)
        tvSoundStatus    = findViewById(R.id.tvSoundStatus)
        tvLastDetection  = findViewById(R.id.tvLastDetection)
        tvTimestamp      = findViewById(R.id.tvTimestamp)

        // ✅ 알림 컨테이너 초기화
        alertContainer = findViewById(R.id.alertContainer)
        alertContainer.visibility = View.GONE
        alertContainer.setOnClickListener {
            // ✅ 컨테이너, 배경 모두 숨기기
            alertContainer.visibility = View.GONE
            backgroundDimmer.visibility = View.GONE
            Log.d("MainActivity", "알림 닫음")
        }

        // ✅ 알림 이미지 초기화
        alertImageView = findViewById(R.id.watchSoundDetectionImage)

        // ✅ 텍스트 레이블 초기화
        alertTextLabel = findViewById(R.id.alertTextLabel)

        // ✅ 배경 초기화
        backgroundDimmer = findViewById(R.id.backgroundDimmer)
        backgroundDimmer.visibility = View.GONE

        // 초기 상태
        tvSoundStatus.text   = getString(R.string.status_waiting)
        tvLastDetection.text = getString(R.string.status_none)
        tvTimestamp.text     = ""

        // Data 레이어 리스너 등록 (기존)
        Wearable.getDataClient(this).addListener(this)

        // ✅ Message 리스너 등록
        Wearable.getMessageClient(this).addListener(this)

        Log.d("MainActivity", "Wear MainActivity 생성됨")
    }

    override fun onDestroy() {
        super.onDestroy()
        WatchMainActivityHolder.mainActivity = null
        Wearable.getDataClient(this).removeListener(this)
        Wearable.getMessageClient(this).removeListener(this)
    }

    // ✅ Message 수신 메서드
    override fun onMessageReceived(messageEvent: MessageEvent) {
        Log.d("MainActivity", "메시지 수신: ${messageEvent.path}")

        when (messageEvent.path) {
            "/doorbell_alert" -> {
                Log.d("MainActivity", "🔔 초인종 메시지 수신")
                showAlertImage("doorbell")
            }
            "/baby_cry_alert" -> {
                Log.d("MainActivity", "👶 아기울음 메시지 수신")
                showAlertImage("baby_cry")
            }
        }
    }

    // DataClient.OnDataChangedListener 구현 (기존)
    override fun onDataChanged(dataEvents: DataEventBuffer) {
        for (event in dataEvents) {
            if (event.type == DataEvent.TYPE_CHANGED &&
                event.dataItem.uri.path == "/sound_detection") {
                val dataMap = DataMapItem.fromDataItem(event.dataItem).dataMap
                val label = dataMap.getString("sound_label", "")
                val conf  = dataMap.getInt("confidence", 0)
                runOnUiThread {
                    updateSoundDetection(label, conf)
                }
            }
        }
    }

    private fun updateSoundDetection(label: String, confidence: Int) {
        tvSoundStatus.text   = getString(R.string.sound_detection_title)
        tvLastDetection.text = "$label\n($confidence%)"
        tvTimestamp.text     = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            .format(Date())
        triggerVibration()
    }

    private fun triggerVibration() {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (vibrator.hasVibrator()) {
            val pattern = longArrayOf(0,300,200,300,200,300)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(pattern, -1)
            }
        }
    }

    // ✅ 알림 이미지 + 텍스트 표시 메서드
    private fun showAlertImage(alertType: String) {
        runOnUiThread {
            Log.d("MainActivity", "알림 표시: $alertType")

            // ✅ 배경과 컨테이너 동시에 표시
            backgroundDimmer.visibility = View.VISIBLE

            when (alertType) {
                "doorbell" -> {
                    // 초인종: 짧은 진동 1회
                    vibrateAlert(longArrayOf(0, 500))

                    try {
                        // ✅ 이미지 설정
                        alertImageView.setImageResource(R.drawable.watchchoinjong1)
                        alertImageView.scaleType = ImageView.ScaleType.CENTER_INSIDE

                        // ✅ 텍스트 설정 (검은색)
                        alertTextLabel.text = "초인종 소리 감지"
                        alertTextLabel.setTextColor(android.graphics.Color.BLACK)

                        // ✅ 컨테이너 표시
                        alertContainer.visibility = View.VISIBLE

                        Log.d("MainActivity", "🔔 초인종 이미지 + 텍스트 표시")
                    } catch (e: Exception) {
                        Log.e("MainActivity", "🔔 이미지 실패: ${e.message}")
                    }
                }
                "baby_cry" -> {
                    // 아기울음: 긴 진동 패턴
                    vibrateAlert(longArrayOf(0, 300, 200, 300))

                    try {
                        // ✅ 이미지 설정
                        alertImageView.setImageResource(R.drawable.watchbabycrying1)
                        alertImageView.scaleType = ImageView.ScaleType.CENTER_INSIDE

                        // ✅ 텍스트 설정 (검은색) - 다시 한번 명시적으로
                        alertTextLabel.text = "아기 울음 소리 감지"
                        alertTextLabel.setTextColor(android.graphics.Color.BLACK)
                        alertTextLabel.textSize = 18f

                        // ✅ 컨테이너 표시
                        alertContainer.visibility = View.VISIBLE

                        Log.d("MainActivity", "👶 아기울음 이미지 + 텍스트 표시")
                    } catch (e: Exception) {
                        Log.e("MainActivity", "👶 이미지 실패: ${e.message}")
                    }
                }
            }
        }
    }

    // ✅ 알림 전용 진동 메서드
    private fun vibrateAlert(pattern: LongArray) {
        try {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (vibrator.hasVibrator()) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(pattern, -1)
                }
            }
        } catch (e: Exception) {
            Log.e("MainActivity", "진동 오류: ${e.message}")
        }
    }

    // ✅ WearMessageListenerService에서 호출될 public 메서드
    fun showSoundDetectionAlert(alertType: String) {
        showAlertImage(alertType)
    }
}
