package com.example.yamnetwatchapp0913

import android.content.Intent
import android.util.Log
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService

/**
 * 스마트폰으로부터 메시지를 수신하여 MainActivity에 전달
 */
class WearMessageListenerService : WearableListenerService() {

    override fun onMessageReceived(messageEvent: MessageEvent) {
        super.onMessageReceived(messageEvent)

        Log.d("WearListener", "메시지 수신: ${messageEvent.path}")

        when (messageEvent.path) {
            "/doorbell_alert" -> {
                Log.d("WearListener", "🔔 초인종 알림 메시지 수신")
                handleDoorbellAlert()
            }
            "/baby_cry_alert" -> {
                Log.d("WearListener", "👶 아기울음 알림 메시지 수신")
                handleBabyCryAlert()
            }
        }
    }

    private fun handleDoorbellAlert() {
        // MainActivity 인스턴스가 있으면 직접 호출
        val mainActivity = WatchMainActivityHolder.mainActivity
        if (mainActivity != null) {
            mainActivity.showSoundDetectionAlert("doorbell")
            Log.d("WearListener", "MainActivity에서 초인종 알림 표시")
        } else {
            // MainActivity가 없으면 메인 액티비티 실행
            val intent = Intent(this, MainActivity::class.java).apply {
                putExtra("alert_type", "doorbell")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            Log.d("WearListener", "MainActivity 시작 (초인종)")
        }
    }

    private fun handleBabyCryAlert() {
        // MainActivity 인스턴스가 있으면 직접 호출
        val mainActivity = WatchMainActivityHolder.mainActivity
        if (mainActivity != null) {
            mainActivity.showSoundDetectionAlert("baby_cry")
            Log.d("WearListener", "MainActivity에서 아기울음 알림 표시")
        } else {
            // MainActivity가 없으면 메인 액티비티 실행
            val intent = Intent(this, MainActivity::class.java).apply {
                putExtra("alert_type", "baby_cry")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            Log.d("WearListener", "MainActivity 시작 (아기울음)")
        }
    }
}
