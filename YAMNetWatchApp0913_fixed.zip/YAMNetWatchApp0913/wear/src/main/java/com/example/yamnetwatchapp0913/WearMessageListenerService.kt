package com.example.yamnetwatchapp0913

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService

/**
 * 폰이 보낸 소리 감지 메시지를 받아 워치에 알린다.
 *
 * 이전에는 static 변수(WatchMainActivityHolder)에 Activity 를 담아 직접 호출했고(메모리 누수),
 * 앱이 꺼져 있을 때는 `alert_type` extra 를 담아 Activity 를 띄웠지만 Activity 가 그 extra 를 읽지 않아
 * 아무것도 표시되지 않았다. 또 Activity 도 같은 메시지를 따로 구독해서 앱이 켜져 있으면 중복 처리됐다.
 *
 * 이제 이 서비스가 유일한 수신 지점이며,
 *  1) 진동하는 헤드업 알림 — 백그라운드에서도 항상 사용자에게 보이고,
 *  2) 가능하면 MainActivity 를 바로 띄워 전체 화면 알림 — (singleTop → onNewIntent 로 전달)
 * 두 가지로 알린다.
 */
class WearMessageListenerService : WearableListenerService() {

    companion object {
        const val EXTRA_ALERT_TYPE = "alert_type"
        const val ALERT_DOORBELL = "doorbell"
        const val ALERT_BABY_CRY = "baby_cry"
        const val NOTIFICATION_ID = 2001

        private const val TAG = "WearListener"
        private const val CHANNEL_ID = "sound_alert_channel"
        private const val PATH_DOORBELL = "/doorbell_alert"
        private const val PATH_BABY_CRY = "/baby_cry_alert"
    }

    override fun onMessageReceived(messageEvent: MessageEvent) {
        super.onMessageReceived(messageEvent)
        Log.d(TAG, "메시지 수신: ${messageEvent.path}")

        val type = when (messageEvent.path) {
            PATH_DOORBELL -> ALERT_DOORBELL
            PATH_BABY_CRY -> ALERT_BABY_CRY
            else -> return
        }
        notifyAlert(type)
    }

    private fun notifyAlert(type: String) {
        val launch = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(EXTRA_ALERT_TYPE, type)
        }

        postNotification(type, launch)

        // 앱이 화면에 떠 있으면 바로 전체 화면 알림으로 전환된다.
        // (백그라운드에서는 시스템이 막을 수 있으므로 실패해도 위의 알림이 안전망이다.)
        try {
            startActivity(launch)
        } catch (e: Exception) {
            Log.w(TAG, "Activity 직접 실행 불가(백그라운드 제한): ${e.message}")
        }
    }

    private fun postNotification(type: String, launch: Intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) return

        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, getString(R.string.noti_channel_alert), NotificationManager.IMPORTANCE_HIGH).apply {
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 500)
                }
            )
        }

        val pendingIntent = PendingIntent.getActivity(
            this, type.hashCode(), launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val title = if (type == ALERT_DOORBELL) R.string.alert_doorbell else R.string.alert_baby_cry
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_alert)
            .setContentTitle(getString(title))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()
        nm.notify(NOTIFICATION_ID, notification)
    }
}
