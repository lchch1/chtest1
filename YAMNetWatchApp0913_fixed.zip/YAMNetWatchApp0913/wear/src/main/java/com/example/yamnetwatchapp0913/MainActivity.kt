package com.example.yamnetwatchapp0913

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 워치 메인 화면. 평소에는 대기 상태를 보여주고, 폰에서 감지 알림이 오면 전체 화면으로 알린다.
 * 알림은 [WearMessageListenerService] 가 `alert_type` extra 와 함께 이 Activity 를 (singleTop) 호출해 전달한다.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var tvSoundStatus: TextView
    private lateinit var tvLastDetection: TextView
    private lateinit var tvTimestamp: TextView

    private lateinit var alertOverlay: View
    private lateinit var alertImageView: ImageView
    private lateinit var alertTextLabel: TextView

    /** 알림 화면이 떠 있을 때만 뒤로가기를 '알림 닫기'로 가로챈다. */
    private val closeAlertOnBack = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = hideAlert()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_wear)

        tvSoundStatus = findViewById(R.id.tvSoundStatus)
        tvLastDetection = findViewById(R.id.tvLastDetection)
        tvTimestamp = findViewById(R.id.tvTimestamp)
        alertOverlay = findViewById(R.id.alertOverlay)
        alertImageView = findViewById(R.id.watchSoundDetectionImage)
        alertTextLabel = findViewById(R.id.alertTextLabel)

        tvSoundStatus.setText(R.string.status_waiting)
        tvLastDetection.setText(R.string.status_none)
        tvTimestamp.text = ""

        alertOverlay.setOnClickListener { hideAlert() }
        onBackPressedDispatcher.addCallback(this, closeAlertOnBack)

        requestNotificationPermissionIfNeeded()

        // 화면 회전·재생성 때 같은 알림이 다시 뜨지 않도록 최초 생성에서만 처리한다.
        if (savedInstanceState == null) handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val type = intent?.getStringExtra(WearMessageListenerService.EXTRA_ALERT_TYPE) ?: return
        intent?.removeExtra(WearMessageListenerService.EXTRA_ALERT_TYPE)
        showAlert(type)
    }

    private fun showAlert(type: String) {
        val (imageRes, textRes, pattern) = when (type) {
            WearMessageListenerService.ALERT_DOORBELL ->
                Triple(R.drawable.watchchoinjong1, R.string.alert_doorbell, longArrayOf(0, 500))
            WearMessageListenerService.ALERT_BABY_CRY ->
                Triple(R.drawable.watchbabycrying1, R.string.alert_baby_cry, longArrayOf(0, 300, 200, 300))
            else -> return
        }

        alertImageView.setImageResource(imageRes)
        alertTextLabel.setText(textRes)
        alertOverlay.visibility = View.VISIBLE
        closeAlertOnBack.isEnabled = true
        vibrate(pattern)

        // 대기 화면에도 마지막 감지 내용을 남긴다.
        tvSoundStatus.setText(R.string.sound_detection_title)
        tvLastDetection.setText(textRes)
        tvTimestamp.text = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

        // 화면에서 직접 보여주고 있으므로 같은 내용의 알림은 걷는다.
        getSystemService(NotificationManager::class.java).cancel(WearMessageListenerService.NOTIFICATION_ID)
    }

    private fun hideAlert() {
        alertOverlay.visibility = View.GONE
        closeAlertOnBack.isEnabled = false
    }

    private fun vibrate(pattern: LongArray) {
        val vibrator = getSystemService(Vibrator::class.java) ?: return
        if (!vibrator.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(pattern, -1)
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }
}
