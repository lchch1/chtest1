plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.example.yamnetwatchapp0913"
    compileSdk = 34

    defaultConfig {
        // 폰 앱과 applicationId 가 같아야 Data Layer 메시지가 연결된다.
        applicationId = "com.example.yamnetwatchapp0913"
        minSdk = 30
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.wear)
    implementation(libs.google.material) // 워치 테마(Theme.MaterialComponents)
    implementation(libs.play.services.wearable)
}
