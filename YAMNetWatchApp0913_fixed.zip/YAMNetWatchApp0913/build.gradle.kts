// 플러그인 버전은 gradle/libs.versions.toml 에서만 관리한다.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
}
