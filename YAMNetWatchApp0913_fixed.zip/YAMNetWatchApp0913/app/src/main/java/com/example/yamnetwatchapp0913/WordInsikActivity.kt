package com.example.yamnetwatchapp0913

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.Build
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/**
 * 단어 인식: 등록한 단어가 대화 속에서 들리면 진동 + 팝업으로 알려 준다.
 * 이 화면이 열려 있는 동안에는 마이크를 음성 인식이 쓰므로 소리 감지 서비스를 잠시 멈춘다.
 */
class WordInsikActivity : AppCompatActivity(), RecognitionListener {

    private lateinit var addword1Button: ImageView
    private lateinit var addWordNameView: ImageView
    private lateinit var wordNameEditText: EditText
    private lateinit var addwordconfirmicon: ImageView
    private lateinit var wordListContainer: LinearLayout
    private lateinit var jjinhadanHome: ImageView

    private val wordList = mutableListOf<WordItem>()
    private lateinit var sharedPreferences: SharedPreferences
    private val gson = Gson()

    private val handler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private var isScreenResumed = false
    private var detectionDialog: AlertDialog? = null

    /** 재시작을 예약하는 Runnable. 화면이 멈추면 취소해서 백그라운드에서 마이크를 켜지 않게 한다. */
    private val restartRunnable = Runnable { startListening() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wordinsik)

        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        addword1Button = findViewById(R.id.addword1)
        addWordNameView = findViewById(R.id.addWordNameView)
        wordNameEditText = findViewById(R.id.wordNameEditText)
        addwordconfirmicon = findViewById(R.id.addwordconfirmicon)
        wordListContainer = findViewById(R.id.wordListContainer)
        jjinhadanHome = findViewById(R.id.jjinhadanhome)

        loadWordList()
        refreshWordList()

        addword1Button.setOnClickListener { showWordInputDialog() }
        addwordconfirmicon.setOnClickListener { confirmWordName() }
        addWordNameView.setOnClickListener { hideWordInputDialog() }
        jjinhadanHome.setOnClickListener { finish() }

        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(this)
            }
        } else {
            Toast.makeText(this, R.string.speech_not_available, Toast.LENGTH_LONG).show()
        }
    }

    // ------------------------------------------------------------------ 수명주기

    override fun onResume() {
        super.onResume()
        isScreenResumed = true
        SoundDetectionService.stop(this) // 마이크 양보
        if (hasMicPermission()) startListening() else requestMicPermission()
    }

    override fun onPause() {
        super.onPause()
        isScreenResumed = false
        handler.removeCallbacks(restartRunnable)
        isListening = false
        speechRecognizer?.cancel()
        SoundDetectionService.start(this) // 화면을 벗어나면 소리 감지 재시작
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        detectionDialog?.dismiss()
        speechRecognizer?.destroy()
        speechRecognizer = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ 음성 인식

    private fun hasMicPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun requestMicPermission() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQ_RECORD_AUDIO)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_RECORD_AUDIO) return
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startListening()
        else Toast.makeText(this, R.string.speech_permission_needed, Toast.LENGTH_LONG).show()
    }

    private fun startListening() {
        if (!isScreenResumed || isListening || !hasMicPermission()) return
        val recognizer = speechRecognizer ?: return

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        isListening = true
        recognizer.startListening(intent)
    }

    private fun scheduleRestart(delayMs: Long) {
        handler.removeCallbacks(restartRunnable)
        handler.postDelayed(restartRunnable, delayMs)
    }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onError(error: Int) {
        isListening = false
        // 권한이 없으면 재시도해도 계속 실패하므로 반복하지 않는다. (이전에는 1.5초마다 무한 재시도)
        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) return
        scheduleRestart(RETRY_DELAY_MS)
    }

    override fun onResults(results: Bundle?) {
        isListening = false
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) checkForMatchingWords(matches.map { it.lowercase() })
        scheduleRestart(NEXT_DELAY_MS)
    }

    private fun checkForMatchingWords(candidates: List<String>) {
        for (word in wordList) {
            if (!word.isOn) continue
            val target = word.name.lowercase()
            if (candidates.any { it.contains(target) }) {
                showWordDetectionDialog(word.name)
                return
            }
        }
    }

    private fun showWordDetectionDialog(detectedWord: String) {
        if (isFinishing || detectionDialog?.isShowing == true) return // 같은 팝업이 겹쳐 쌓이지 않게

        vibrate(400)

        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_word_detection, null)
        dialogView.findViewById<TextView>(R.id.tvGuidanceTitle).setText(R.string.word_detected_title)
        dialogView.findViewById<TextView>(R.id.tvWordDetected).text =
            getString(R.string.word_detected_message, detectedWord)

        val dialog = AlertDialog.Builder(this).setView(dialogView).setCancelable(false).create()
        dialogView.findViewById<Button>(R.id.btnUnderstand).setOnClickListener { dialog.dismiss() }
        dialog.show()
        detectionDialog = dialog
    }

    private fun vibrate(durationMs: Long) {
        val vibrator = getSystemService(Vibrator::class.java) ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(durationMs)
        }
    }

    // ------------------------------------------------------------------ 단어 목록

    private fun showWordInputDialog() {
        addWordNameView.visibility = View.VISIBLE
        wordNameEditText.visibility = View.VISIBLE
        addwordconfirmicon.visibility = View.VISIBLE
        wordNameEditText.setText("")
        wordNameEditText.requestFocus()
        getSystemService(InputMethodManager::class.java)
            ?.showSoftInput(wordNameEditText, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideWordInputDialog() {
        getSystemService(InputMethodManager::class.java)
            ?.hideSoftInputFromWindow(wordNameEditText.windowToken, 0)
        addWordNameView.visibility = View.GONE
        wordNameEditText.visibility = View.GONE
        addwordconfirmicon.visibility = View.GONE
    }

    private fun confirmWordName() {
        val wordName = wordNameEditText.text.toString().trim()
        if (wordName.isEmpty()) return

        // 같은 단어를 두 번 등록하지 않는다.
        if (wordList.none { it.name.equals(wordName, ignoreCase = true) }) {
            // 새로 추가한 단어는 바로 감지되도록 켜 둔 상태로 시작한다. (이전에는 꺼진 채 추가돼 직접 켜야 했다)
            wordList.add(WordItem(wordName, true))
            saveWordList()
            refreshWordList()
        }
        hideWordInputDialog()
    }

    private fun refreshWordList() {
        wordListContainer.removeAllViews()

        for (wordItem in wordList.toList()) {
            val itemView = layoutInflater.inflate(R.layout.item_word, wordListContainer, false)
            itemView.findViewById<TextView>(R.id.wordItemName).text = wordItem.name

            val toggle = itemView.findViewById<ImageView>(R.id.wordItemToggle)
            toggle.setImageResource(if (wordItem.isOn) R.drawable.wordinsikonswitch else R.drawable.wordinsikoffswitch)
            toggle.setOnClickListener {
                wordItem.isOn = !wordItem.isOn
                saveWordList()
                refreshWordList()
            }

            itemView.findViewById<ImageView>(R.id.wordItemDelete).setOnClickListener {
                wordList.remove(wordItem)
                saveWordList()
                refreshWordList()
            }

            wordListContainer.addView(itemView)
        }
    }

    private fun saveWordList() {
        sharedPreferences.edit().putString(WORD_LIST_KEY, gson.toJson(wordList)).apply()
    }

    private fun loadWordList() {
        val json = sharedPreferences.getString(WORD_LIST_KEY, null) ?: return
        try {
            val type = object : TypeToken<List<WordItem>>() {}.type
            val saved: List<WordItem>? = gson.fromJson(json, type)
            wordList.clear()
            saved?.let { wordList.addAll(it) }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private companion object {
        const val PREFS_NAME = "word_prefs"
        const val WORD_LIST_KEY = "word_list"
        const val REQ_RECORD_AUDIO = 101
        const val RETRY_DELAY_MS = 1500L
        const val NEXT_DELAY_MS = 1500L
    }
}
