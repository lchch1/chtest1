package com.example.yamnetwatchapp0913

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

/** 온보딩 3단계: 아기 울음소리 알림이 필요한지 */
class Intro3Activity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var answered = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_intro3)

        bind(R.id.kidyes, true)
        bind(R.id.kidno, false)
    }

    private fun bind(id: Int, hasKid: Boolean) {
        val view = findViewById<ImageView>(id)
        view.setPressAlphaFeedback()
        view.setOnClickListener { answer(hasKid) }
    }

    private fun answer(hasKid: Boolean) {
        if (answered) return
        answered = true
        SoundPrefs.setEverywhere(this, listOf(SoundKind.BABY_CRY), hasKid)
        handler.postDelayed({
            startActivity(Intent(this, Intro4Activity::class.java).putExtra("HAS_KID", hasKid))
            finish()
        }, NAV_DELAY_MS)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private companion object {
        const val NAV_DELAY_MS = 300L
    }
}
