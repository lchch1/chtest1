package com.example.yamnetwatchapp0913

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash2)

        // [P0] 이전에는 실행할 때마다 SharedPreferences 를 전부 지우고 항상 온보딩으로 보냈다.
        //      이제는 최초 1회만 온보딩으로, 이후에는 바로 메인으로 이동하고 설정을 보존한다.
        handler.postDelayed({
            val next = if (AppPrefs.isFirstRun(this)) IntroActivity::class.java else MainActivity::class.java
            startActivity(Intent(this, next))
            finish()
        }, SPLASH_MS)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private companion object {
        const val SPLASH_MS = 1500L
    }
}
