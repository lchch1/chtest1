package com.example.yamnetwatchapp0913

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

/** 호출음 화면: 미리 등록한 음성 파일을 재생해 주변 사람을 부른다. */
class HochulActivity : AppCompatActivity() {

    private lateinit var jjinhadansetting: ImageView
    private lateinit var addVoiceFileButton: ImageView
    private lateinit var recyclerView: RecyclerView
    private lateinit var addmp3nameView: View
    private lateinit var mp3NameEditText: EditText
    private lateinit var addmp3confirmicon: ImageView
    private lateinit var jjinhadanhome: ImageView

    private val audioList = mutableListOf<AudioFile>()
    private lateinit var audioAdapter: AudioAdapter
    private var mediaPlayer: MediaPlayer? = null
    private var selectedAudioUri: Uri? = null

    private lateinit var sharedPreferences: SharedPreferences
    private val gson = Gson()

    private val pickAudioLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            selectedAudioUri = it
            showNameInputDialog()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hochul)

        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        jjinhadansetting = findViewById(R.id.jjinhadansetting)
        addVoiceFileButton = findViewById(R.id.addvoicefile)
        recyclerView = findViewById(R.id.audioRecyclerView)
        addmp3nameView = findViewById(R.id.addmp3name)
        mp3NameEditText = findViewById(R.id.mp3NameEditText)
        addmp3confirmicon = findViewById(R.id.addmp3confirmicon)
        jjinhadanhome = findViewById(R.id.jjinhadanhome)

        loadAudioList()

        audioAdapter = AudioAdapter(audioList, { playAudio(it) }, { deleteAudio(it) })
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = audioAdapter

        addVoiceFileButton.setOnClickListener { pickAudioLauncher.launch("audio/*") }
        addmp3confirmicon.setOnClickListener { confirmMp3Name() }
        addmp3nameView.setOnClickListener { hideNameInputDialog() }

        jjinhadanhome.setOnClickListener {
            SoundDetectionService.start(this)
            finish()
        }
        jjinhadansetting.setOnClickListener {
            startActivity(Intent(this, SettingActivity::class.java))
            overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right)
        }
    }

    // ------------------------------------------------------------------ 이름 입력 팝업

    private fun showNameInputDialog() {
        addmp3nameView.visibility = View.VISIBLE
        mp3NameEditText.visibility = View.VISIBLE
        addmp3confirmicon.visibility = View.VISIBLE
        mp3NameEditText.setText("")
        mp3NameEditText.requestFocus()
        getSystemService(InputMethodManager::class.java)
            ?.showSoftInput(mp3NameEditText, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideNameInputDialog() {
        getSystemService(InputMethodManager::class.java)
            ?.hideSoftInputFromWindow(mp3NameEditText.windowToken, 0)
        addmp3nameView.visibility = View.GONE
        mp3NameEditText.visibility = View.GONE
        addmp3confirmicon.visibility = View.GONE
    }

    // ------------------------------------------------------------------ 파일 저장

    private fun confirmMp3Name() {
        val displayName = mp3NameEditText.text.toString().trim()
        if (displayName.isEmpty()) return
        val sourceUri = selectedAudioUri ?: return

        val target = uniqueTargetFile(displayName)
        hideNameInputDialog()
        selectedAudioUri = null

        // 큰 파일을 메인 스레드에서 복사하면 화면이 멈추므로 백그라운드에서 복사한다.
        Thread {
            val copied = try {
                contentResolver.openInputStream(sourceUri)?.use { input ->
                    target.outputStream().use { output -> input.copyTo(output) }
                } != null
            } catch (e: Exception) {
                Log.e(TAG, "파일 복사 오류: ${e.message}")
                false
            }

            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (copied) {
                    audioList.add(AudioFile(displayName, Uri.fromFile(target)))
                    audioAdapter.notifyItemInserted(audioList.size - 1)
                    saveAudioList()
                } else {
                    target.delete()
                    Toast.makeText(this, R.string.audio_copy_failed, Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    /**
     * 사용자가 입력한 이름으로 앱 전용 폴더에 저장할 파일을 만든다.
     * 이름에 `/`, `..` 같은 문자가 있으면 앱 폴더 밖에 쓰거나 크래시할 수 있어 안전한 문자만 남기고,
     * 같은 이름이 이미 있으면 덮어쓰지 않고 번호를 붙인다.
     */
    private fun uniqueTargetFile(displayName: String): File {
        val dir = File(filesDir, AUDIO_DIR).apply { mkdirs() }
        val base = displayName
            .replace(Regex("[^\\p{L}\\p{N} _.-]"), "_")
            .trim()
            .trim('.')
            .take(60)
            .ifEmpty { "audio" }
        var file = File(dir, "$base.mp3")
        var n = 1
        while (file.exists()) {
            file = File(dir, "${base}_$n.mp3")
            n++
        }
        return file
    }

    // ------------------------------------------------------------------ 재생 / 삭제

    private fun deleteAudio(position: Int) {
        if (position < 0 || position >= audioList.size) return
        val removed = audioList.removeAt(position)
        audioAdapter.notifyItemRemoved(position)
        saveAudioList()

        // 앱이 만든 파일이면 실제 파일도 지워 저장 공간이 계속 늘어나지 않게 한다.
        val path = removed.uri.path
        if (removed.uri.scheme == "file" && path != null && path.startsWith(filesDir.absolutePath)) {
            File(path).delete()
        }
    }

    private fun playAudio(audioFile: AudioFile) {
        val uri = audioFile.uri
        val path = uri.path
        if (uri.scheme == "file" && (path == null || !File(path).exists())) {
            Toast.makeText(this, R.string.audio_file_not_found, Toast.LENGTH_SHORT).show()
            return
        }
        try {
            releasePlayer()
            mediaPlayer = MediaPlayer().apply {
                setDataSource(this@HochulActivity, uri)
                setOnCompletionListener { mp ->
                    mp.release()
                    if (mediaPlayer === mp) mediaPlayer = null
                }
                setOnErrorListener { mp, _, _ ->
                    mp.release()
                    if (mediaPlayer === mp) mediaPlayer = null
                    true
                }
                prepare()
                start()
            }
        } catch (e: Exception) {
            Log.e(TAG, "오디오 재생 오류: ${e.message}")
            releasePlayer()
            Toast.makeText(this, R.string.audio_file_not_found, Toast.LENGTH_SHORT).show()
        }
    }

    private fun releasePlayer() {
        mediaPlayer?.release()
        mediaPlayer = null
    }

    // ------------------------------------------------------------------ 목록 저장/불러오기

    private fun saveAudioList() {
        val json = gson.toJson(audioList.map { AudioFileData(it.name, it.uri.toString()) })
        sharedPreferences.edit().putString(AUDIO_LIST_KEY, json).apply()
    }

    private fun loadAudioList() {
        val json = sharedPreferences.getString(AUDIO_LIST_KEY, null) ?: return
        try {
            val type = object : TypeToken<List<AudioFileData>>() {}.type
            val saved: List<AudioFileData>? = gson.fromJson(json, type)
            audioList.clear()
            saved?.let { list -> audioList.addAll(list.map { AudioFile(it.name, Uri.parse(it.uriString)) }) }
        } catch (e: Exception) {
            Log.e(TAG, "목록 불러오기 실패: ${e.message}")
        }
    }

    override fun onPause() {
        super.onPause()
        releasePlayer() // 화면을 떠나면 재생을 멈춘다
    }

    override fun onDestroy() {
        super.onDestroy()
        releasePlayer()
    }

    private companion object {
        const val TAG = "Hochul"
        const val PREFS_NAME = "audio_prefs"
        const val AUDIO_LIST_KEY = "audio_list"
        const val AUDIO_DIR = "audio"
    }
}
