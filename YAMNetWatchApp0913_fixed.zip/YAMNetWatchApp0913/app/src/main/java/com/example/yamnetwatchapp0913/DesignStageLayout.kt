package com.example.yamnetwatchapp0913

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * 디자인 캔버스(기본 412 x 917dp)를 화면에 맞춰 **비율을 유지한 채 균일하게 확대/축소**하는 컨테이너.
 *
 * 기존 화면은 RelativeLayout 에 `layout_marginLeft="337dp"` 같은 고정 dp 좌표를 박아 둔 구조라
 * 화면 크기/비율이 달라지면 아이콘이 배경 이미지와 어긋나거나 잘렸다.
 * 이 컨테이너는 자식 뷰의 XML 좌표/크기(디자인 dp 기준)를 그대로 읽어 `scale` 배로 배치한다.
 *
 *  - scale = min(가용 폭 / 디자인 폭, 가용 높이 / 디자인 높이)  → 어떤 기기에서도 잘리지 않는다(contain).
 *  - 남는 영역은 가운데 정렬되고, 컨테이너 자체 배경(그라데이션 등)은 화면 전체에 채워진다.
 *  - 음수 마진/캔버스 밖으로 번지는 장식 이미지도 그대로 표현된다 (clipChildren=false).
 *  - 코드에서 `MarginLayoutParams` 의 width/height/margin 을 바꿔도(= 기존 moveSmallBlue 방식) 자동으로 scale 이 적용된다.
 *
 * 자식은 `layout_marginLeft`, `layout_marginTop`, `layout_width`, `layout_height` 만 사용한다.
 * (`wrap_content` 는 자연 크기를 scale 배, `match_parent` 는 캔버스 전체를 의미)
 */
class DesignStageLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : ViewGroup(context, attrs, defStyleAttr) {

    private val geometry: StageGeometry

    /** 현재 적용 중인 배율 (디자인 1dp 가 화면에서 몇 dp 인지) */
    val scale: Float get() = geometry.scale

    init {
        val density = resources.displayMetrics.density
        var designWidthPx = DEFAULT_DESIGN_WIDTH_DP * density
        var designHeightPx = DEFAULT_DESIGN_HEIGHT_DP * density

        if (attrs != null) {
            val a = context.obtainStyledAttributes(attrs, R.styleable.DesignStageLayout, defStyleAttr, 0)
            try {
                designWidthPx = a.getDimension(R.styleable.DesignStageLayout_designWidth, designWidthPx)
                designHeightPx = a.getDimension(R.styleable.DesignStageLayout_designHeight, designHeightPx)
            } finally {
                a.recycle()
            }
        }
        geometry = StageGeometry(designWidthPx, designHeightPx)

        // 캔버스 밖으로 번지는 장식 이미지(음수 마진)를 자르지 않는다.
        clipChildren = false
        clipToPadding = false
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        // 부모가 준 크기를 그대로 채운다. 제약이 없으면(UNSPECIFIED) 디자인 크기를 사용한다.
        val width = resolve(widthMeasureSpec, geometry.designWidth)
        val height = resolve(heightMeasureSpec, geometry.designHeight)
        setMeasuredDimension(width, height)
        geometry.fit(width, height)

        for (i in 0 until childCount) {
            val child = getChildAt(i)
            if (child.visibility == View.GONE) continue
            val lp = child.layoutParams as MarginLayoutParams
            val childW = childExtent(child, lp.width, geometry.designWidth, horizontal = true)
            val childH = childExtent(child, lp.height, geometry.designHeight, horizontal = false)
            child.measure(
                MeasureSpec.makeMeasureSpec(childW, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(childH, MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            if (child.visibility == View.GONE) continue
            val lp = child.layoutParams as MarginLayoutParams
            val left = geometry.left(lp.leftMargin)
            val top = geometry.top(lp.topMargin)
            child.layout(left, top, left + child.measuredWidth, top + child.measuredHeight)
        }
    }

    private fun resolve(spec: Int, designPx: Float): Int =
        if (MeasureSpec.getMode(spec) == MeasureSpec.UNSPECIFIED) designPx.roundToInt()
        else MeasureSpec.getSize(spec)

    private fun childExtent(child: View, size: Int, designPx: Float, horizontal: Boolean): Int =
        when (size) {
            LayoutParams.MATCH_PARENT -> geometry.scaled(designPx.roundToInt())
            LayoutParams.WRAP_CONTENT -> {
                // 자연 크기를 먼저 측정한 뒤 scale 을 곱한다.
                val unspecified = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
                child.measure(unspecified, unspecified)
                geometry.scaled(if (horizontal) child.measuredWidth else child.measuredHeight)
            }
            else -> geometry.scaled(size)
        }

    override fun generateLayoutParams(attrs: AttributeSet): LayoutParams = MarginLayoutParams(context, attrs)

    override fun generateDefaultLayoutParams(): LayoutParams =
        MarginLayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)

    override fun generateLayoutParams(p: LayoutParams): LayoutParams = MarginLayoutParams(p)

    override fun checkLayoutParams(p: LayoutParams): Boolean = p is MarginLayoutParams

    companion object {
        const val DEFAULT_DESIGN_WIDTH_DP = 412f
        const val DEFAULT_DESIGN_HEIGHT_DP = 917f
    }
}

/**
 * [DesignStageLayout] 의 배율/정렬 계산. Android 에 의존하지 않아 JVM 에서 바로 검증할 수 있다.
 *
 * @param designWidth  디자인 캔버스 폭 (px)
 * @param designHeight 디자인 캔버스 높이 (px)
 */
internal class StageGeometry(val designWidth: Float, val designHeight: Float) {

    var scale = 1f
        private set
    var offsetX = 0f
        private set
    var offsetY = 0f
        private set

    /** 가용 영역(px)에 캔버스 전체가 잘리지 않게 들어가는 최대 배율을 구하고, 가운데 정렬 오프셋을 계산한다. */
    fun fit(availableWidth: Int, availableHeight: Int) {
        scale = max(MIN_SCALE, min(availableWidth / designWidth, availableHeight / designHeight))
        offsetX = (availableWidth - designWidth * scale) / 2f
        offsetY = (availableHeight - designHeight * scale) / 2f
    }

    /** 디자인 크기(px) → 화면 크기(px) */
    fun scaled(designPx: Int): Int = (designPx * scale).roundToInt()

    /** 디자인 left 마진(px) → 화면 x 좌표 */
    fun left(designMarginPx: Int): Int = (offsetX + designMarginPx * scale).roundToInt()

    /** 디자인 top 마진(px) → 화면 y 좌표 */
    fun top(designMarginPx: Int): Int = (offsetY + designMarginPx * scale).roundToInt()

    private companion object {
        const val MIN_SCALE = 0.01f
    }
}
