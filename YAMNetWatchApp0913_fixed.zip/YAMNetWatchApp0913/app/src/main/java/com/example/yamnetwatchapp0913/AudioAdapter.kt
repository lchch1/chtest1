package com.example.yamnetwatchapp0913

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AudioAdapter(
    private val audioList: MutableList<AudioFile>,
    private val onPlayClick: (AudioFile) -> Unit,
    private val onDeleteClick: (Int) -> Unit
) : RecyclerView.Adapter<AudioAdapter.AudioViewHolder>() {

    inner class AudioViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val fileNameTextView: TextView = itemView.findViewById(R.id.fileNameTextView)
        private val playMp3Button: ImageView = itemView.findViewById(R.id.playMp3Button)
        private val deleteMp3Button: ImageView = itemView.findViewById(R.id.deleteMp3Button)

        fun bind(audioFile: AudioFile) {
            fileNameTextView.text = audioFile.name
            playMp3Button.setOnClickListener { onPlayClick(audioFile) }
            deleteMp3Button.setOnClickListener {
                // 삭제 애니메이션 중에는 NO_POSITION 이 올 수 있어 확인한다.
                val position = bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) onDeleteClick(position)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AudioViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_audio_file, parent, false)
        return AudioViewHolder(view)
    }

    override fun onBindViewHolder(holder: AudioViewHolder, position: Int) {
        holder.bind(audioList[position])
    }

    override fun getItemCount(): Int = audioList.size
}
