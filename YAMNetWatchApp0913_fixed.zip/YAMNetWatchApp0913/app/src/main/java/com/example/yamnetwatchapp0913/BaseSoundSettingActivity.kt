package com.example.yamnetwatchapp0913

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat

/**
 * 모드별 '소리 설정' 화면의 공통 구현.
 *
 * 이전에는 6개 화면(SoundSettingActivity, SoundSetting2~6Activity)이 거의 같은 코드를 복사해 두었고
 * (그리고 이 Base 클래스는 아무도 상속하지 않았다), 화면마다 SharedPreferences 파일/키/스위치 id 이름이
 * 제각각이었다. 이제 각 화면은 레이아웃과 모드만 지정한다.
 *
 * - 스위치 sw1..swN 은 [AppMode.sounds] 의 순서와 같다.
 * - 스위치를 누르는 즉시 저장한다. (감지 서비스는 저장값을 바로 읽는다)
 * - 스위치 이미지는 글자가 없으므로 TalkBack 이 "초인종 소리 알림, 켜짐" 처럼 읽도록 설명을 단다.
 */
abstract class BaseSoundSettingActivity : AppCompatActivity() {

    protected abstract val layoutResId: Int
    protected abstract val mode: AppMode

    private val switchIds = intArrayOf(
        R.id.sw1, R.id.sw2, R.id.sw3, R.id.sw4, R.id.sw5, R.id.sw6, R.id.sw7
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layoutResId)

        mode.sounds.forEachIndexed { index, kind ->
            val view = findViewById<ImageView>(switchIds[index]) ?: return@forEachIndexed
            render(view, kind, SoundPrefs.isOn(this, mode, kind))
            view.setOnClickListener {
                val newState = !SoundPrefs.isOn(this, mode, kind)
                SoundPrefs.setOn(this, mode, kind, newState)
                render(view, kind, newState)
            }
        }

        findViewById<ImageView>(R.id.jjinhadanhome)?.setOnClickListener {
            SoundDetectionService.start(this)
            finish()
        }
    }

    private fun render(view: ImageView, kind: SoundKind, isOn: Boolean) {
        view.setImageResource(if (isOn) R.drawable.ssonswitch else R.drawable.ssoffswitch)
        view.contentDescription = getString(R.string.cd_sound_switch, getString(kind.labelRes))
        ViewCompat.setStateDescription(
            view, getString(if (isOn) R.string.state_on else R.string.state_off)
        )
    }
}
