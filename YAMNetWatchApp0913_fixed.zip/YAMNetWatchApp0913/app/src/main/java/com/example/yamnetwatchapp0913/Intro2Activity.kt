package com.example.yamnetwatchapp0913

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

/** 온보딩 2단계: 반려동물(개/고양이) 소리 알림이 필요한지 */
class Intro2Activity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var answered = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_intro2)

        bind(R.id.introdogyes, true)
        bind(R.id.introdogno, false)
    }

    private fun bind(id: Int, hasPet: Boolean) {
        val view = findViewById<ImageView>(id)
        view.setPressAlphaFeedback()
        view.setOnClickListener { answer(hasPet) }
    }

    private fun answer(hasPet: Boolean) {
        if (answered) return          // 연타해도 한 번만 이동
        answered = true
        // 개/고양이 스위치가 있는 모든 모드에 한꺼번에 반영한다.
        // (이전에는 모드마다 다른 SharedPreferences 파일/키를 개별 저장했고, '내 모드'는 빠져 있었다.)
        SoundPrefs.setEverywhere(this, listOf(SoundKind.DOG, SoundKind.CAT), hasPet)
        handler.postDelayed({
            startActivity(Intent(this, Intro3Activity::class.java).putExtra("HAS_PET", hasPet))
            finish()
        }, NAV_DELAY_MS)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private companion object {
        const val NAV_DELAY_MS = 300L
    }
}
