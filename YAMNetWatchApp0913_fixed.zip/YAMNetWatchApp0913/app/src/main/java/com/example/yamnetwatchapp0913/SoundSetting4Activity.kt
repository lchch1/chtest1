package com.example.yamnetwatchapp0913

class SoundSetting4Activity : BaseSoundSettingActivity() {
    override val layoutResId: Int get() = R.layout.activity_soundsetting4
    override val mode: AppMode get() = AppMode.WORK
}
