package com.example.yamnetwatchapp0913

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.yamnetwatchapp0913.databinding.ActivityMainBinding

/**
 * 메인 화면.
 *
 * 레이아웃은 [DesignStageLayout] 이 412x917dp 디자인 캔버스를 화면에 맞춰 균일하게 배율 조정한다.
 * 이 클래스의 좌표(dp)는 모두 **디자인 캔버스 기준**이며, 실제 화면 배율은 컨테이너가 적용한다.
 * (이전: 화면 크기와 무관한 고정 px 로 마진을 계산해 기기마다 아이콘이 어긋났다.)
 *
 * 소리 감지는 [SoundDetectionService] 가 담당하고, 이 화면은 결과를 받아 팝업만 보여준다.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var vibrator: Vibrator? = null

    private var currentMode = AppMode.HOME
    private var isAlarmOn = true
    private var isDoorbellShowing = false
    private var isBabycryingShowing = false
    private var receiverRegistered = false

    /** 모드별 디자인 좌표: 선택 표시(smallblue) 위치 + 중앙 큰 아이콘 크기/위치 (dp) */
    private class Geometry(
        val blueLeft: Int, val blueTop: Int,
        val bigWidth: Int, val bigHeight: Int, val bigLeft: Int, val bigTop: Int
    )

    private val geometry = mapOf(
        AppMode.HOME to Geometry(89, 199, 134, 147, 131, 172),
        AppMode.DRIVING to Geometry(181, 133, 130, 170, 138, 172),
        AppMode.WORK to Geometry(282, 203, 134, 159, 131, 172),
        AppMode.TRANSIT to Geometry(103, 303, 134, 182, 131, 172),
        AppMode.SCHOOL to Geometry(263, 308, 134, 147, 131, 172),
        AppMode.MYMENU to Geometry(186, 342, 138, 145, 131, 170)
    )

    private val modeIcons: Map<AppMode, ImageView> by lazy {
        mapOf(
            AppMode.HOME to binding.home, AppMode.DRIVING to binding.driving, AppMode.WORK to binding.work,
            AppMode.TRANSIT to binding.transit, AppMode.SCHOOL to binding.school, AppMode.MYMENU to binding.mymenu
        )
    }
    private val bigIcons: Map<AppMode, ImageView> by lazy {
        mapOf(
            AppMode.HOME to binding.bighome, AppMode.DRIVING to binding.bigdriving, AppMode.WORK to binding.bigwork,
            AppMode.TRANSIT to binding.bigtransit, AppMode.SCHOOL to binding.bigschool, AppMode.MYMENU to binding.bigmymode
        )
    }
    private val modeImages = mapOf(
        AppMode.HOME to (R.drawable.home to R.drawable.offhome),
        AppMode.DRIVING to (R.drawable.driving to R.drawable.offdriving),
        AppMode.WORK to (R.drawable.work to R.drawable.offwork),
        AppMode.TRANSIT to (R.drawable.transit to R.drawable.offtransit),
        AppMode.SCHOOL to (R.drawable.school to R.drawable.offschool),
        AppMode.MYMENU to (R.drawable.mymenu1 to R.drawable.offmymode)
    )

    /** 서비스가 보낸 감지 결과 (순서 브로드캐스트). 처리하면 RESULT_OK 로 응답해 중복 알림을 막는다. */
    private val detectionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (isOrderedBroadcast) resultCode = Activity.RESULT_OK
            if (!isAlarmOn) return
            showAlert(intent?.getStringExtra(SoundDetectionService.EXTRA_TYPE))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        vibrator = getSystemService(Vibrator::class.java)
        isAlarmOn = AppPrefs.isAlarmOn(this)

        applyBigIconGeometry()
        updateModeIconsState()
        setupClickListeners()

        val saved = AppMode.fromKey(savedInstanceState?.getString(STATE_MODE))
        currentMode = saved?.takeIf { AppPrefs.isModeEnabled(this, it) } ?: firstEnabledMode()
        renderAlarmState()

        // 알림(헤드업)을 눌러 들어온 경우 해당 팝업을 보여준다. (화면 회전 후 재생성 시에는 다시 띄우지 않는다)
        if (savedInstanceState == null) showAlert(intent?.getStringExtra(SoundDetectionService.EXTRA_TYPE))

        requestRuntimePermissions()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        showAlert(intent.getStringExtra(SoundDetectionService.EXTRA_TYPE))
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(STATE_MODE, currentMode.key)
    }

    // ------------------------------------------------------------------ 모드 / 알림 상태

    private fun firstEnabledMode(): AppMode =
        listOf(AppMode.HOME, AppMode.DRIVING, AppMode.WORK, AppMode.TRANSIT, AppMode.SCHOOL)
            .firstOrNull { AppPrefs.isModeEnabled(this, it) } ?: AppMode.HOME

    /** 큰 아이콘의 크기/위치는 모드마다 고정이므로 한 번만 지정한다. (표시 여부만 바꾼다) */
    private fun applyBigIconGeometry() {
        val density = resources.displayMetrics.density
        for ((mode, view) in bigIcons) {
            val g = geometry.getValue(mode)
            val lp = view.layoutParams as ViewGroup.MarginLayoutParams
            lp.width = (g.bigWidth * density).toInt()
            lp.height = (g.bigHeight * density).toInt()
            lp.leftMargin = (g.bigLeft * density).toInt()
            lp.topMargin = (g.bigTop * density).toInt()
            view.layoutParams = lp
        }
    }

    private fun moveSmallBlue(mode: AppMode) {
        val density = resources.displayMetrics.density
        val g = geometry.getValue(mode)
        val lp = binding.smallblue.layoutParams as ViewGroup.MarginLayoutParams
        lp.leftMargin = (g.blueLeft * density).toInt()
        lp.topMargin = (g.blueTop * density).toInt()
        binding.smallblue.layoutParams = lp
    }

    private fun updateModeIconsState() {
        for ((mode, view) in modeIcons) {
            if (!AppPrefs.isModeEnabled(this, mode)) {
                view.setImageResource(modeImages.getValue(mode).second)
                view.isEnabled = false
            }
        }
    }

    private fun selectMode(mode: AppMode) {
        currentMode = mode
        moveSmallBlue(mode)
        showBigIcon(mode)
    }

    private fun showBigIcon(mode: AppMode) {
        hideAllBigIcons()
        bigIcons.getValue(mode).visibility = View.VISIBLE
    }

    private fun hideAllBigIcons() {
        bigIcons.values.forEach { it.visibility = View.GONE }
    }

    /** 알림 on/off 상태를 화면에 반영한다. */
    private fun renderAlarmState() = with(binding) {
        if (isAlarmOn) {
            alarmOffIcon.visibility = View.GONE
            alarmOnIcon.visibility = View.VISIBLE
            offAlarmOffIcon.visibility = View.GONE
            smallblue.visibility = View.VISIBLE
            for ((mode, view) in modeIcons) {
                if (AppPrefs.isModeEnabled(this@MainActivity, mode)) {
                    view.setImageResource(modeImages.getValue(mode).first)
                }
            }
            selectMode(currentMode)
        } else {
            alarmOnIcon.visibility = View.GONE
            alarmOffIcon.visibility = View.VISIBLE
            offAlarmOffIcon.visibility = View.VISIBLE
            smallblue.visibility = View.GONE
            modeIcons.forEach { (mode, view) -> view.setImageResource(modeImages.getValue(mode).second) }
            hideAllBigIcons()
        }
    }

    private fun setAlarm(on: Boolean) {
        isAlarmOn = on
        AppPrefs.setAlarmOn(this, on)
        renderAlarmState()
        if (on) SoundDetectionService.start(this) else SoundDetectionService.stop(this)
    }

    private fun setupClickListeners() = with(binding) {
        for ((mode, view) in modeIcons) {
            view.setOnClickListener {
                if (isAlarmOn && AppPrefs.isModeEnabled(this@MainActivity, mode)) selectMode(mode)
            }
        }

        alarmOnIcon.setOnClickListener { setAlarm(false) }
        alarmOffIcon.setOnClickListener { setAlarm(true) }

        soundSettingIcon.setOnClickListener { open(settingsScreenFor(currentMode)) }
        lefttalk.setOnClickListener { open(ChatActivity::class.java) }
        righthochul.setOnClickListener { open(HochulActivity::class.java) }
        wordinsik.setOnClickListener { open(WordInsikActivity::class.java) }
        jjinhadansetting.setOnClickListener { open(SettingActivity::class.java) }

        doorbellDetectionImage.setOnClickListener { hideDoorbellImage() }
        doorbellDetectionImage1.setOnClickListener { hideDoorbellImage() }
        babycryingDetectionImage.setOnClickListener { hideBabycryingImage() }
        babycryingDetectionImage1.setOnClickListener { hideBabycryingImage() }
    }

    private fun settingsScreenFor(mode: AppMode): Class<*> = when (mode) {
        AppMode.HOME -> SoundSettingActivity::class.java
        AppMode.DRIVING -> SoundSetting3Activity::class.java
        AppMode.WORK -> SoundSetting4Activity::class.java
        AppMode.TRANSIT -> SoundSetting2Activity::class.java
        AppMode.SCHOOL -> SoundSetting5Activity::class.java
        AppMode.MYMENU -> SoundSetting6Activity::class.java
    }

    private fun open(target: Class<*>) {
        startActivity(Intent(this, target))
        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right)
    }

    // ------------------------------------------------------------------ 감지 팝업

    private fun showAlert(type: String?) {
        when (type) {
            SoundDetectionService.TYPE_DOORBELL -> showDoorbellImage()
            SoundDetectionService.TYPE_BABY_CRY -> showBabycryingImage()
        }
    }

    private fun showDoorbellImage() {
        if (isDoorbellShowing || isBabycryingShowing) return
        vibrateDevice(500)
        isDoorbellShowing = true
        hideAllBigIcons()
        binding.doorbellDetectionImage1.visibility = View.VISIBLE
        binding.doorbellDetectionImage.visibility = View.VISIBLE
        setControlsClickable(false)
    }

    private fun hideDoorbellImage() {
        binding.doorbellDetectionImage.visibility = View.GONE
        binding.doorbellDetectionImage1.visibility = View.GONE
        // 팝업이 닫히면 현재 모드의 큰 아이콘을 복원한다 (이전에는 홈 아이콘으로 고정되던 버그)
        if (isAlarmOn) showBigIcon(currentMode)
        isDoorbellShowing = false
        setControlsClickable(true)
    }

    private fun showBabycryingImage() {
        if (isDoorbellShowing || isBabycryingShowing) return
        vibrateDevice(300)
        isBabycryingShowing = true
        hideAllBigIcons()
        binding.babycryingDetectionImage1.visibility = View.VISIBLE
        binding.babycryingDetectionImage.visibility = View.VISIBLE
        setControlsClickable(false)
    }

    private fun hideBabycryingImage() {
        binding.babycryingDetectionImage.visibility = View.GONE
        binding.babycryingDetectionImage1.visibility = View.GONE
        if (isAlarmOn) showBigIcon(currentMode)
        isBabycryingShowing = false
        setControlsClickable(true)
    }

    private fun setControlsClickable(clickable: Boolean) = with(binding) {
        alarmOnIcon.isClickable = clickable
        alarmOffIcon.isClickable = clickable
        soundSettingIcon.isClickable = clickable
    }

    private fun vibrateDevice(duration: Long) {
        val v = vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(duration)
        }
    }

    // ------------------------------------------------------------------ 권한 / 수명주기

    private fun requestRuntimePermissions() {
        val wanted = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = wanted.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) SoundDetectionService.start(this)
        else ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQ_PERMISSIONS)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERMISSIONS) return
        val micGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (micGranted) SoundDetectionService.start(this)
        else Toast.makeText(this, R.string.mic_permission_needed, Toast.LENGTH_LONG).show()
    }

    override fun onResume() {
        super.onResume()
        if (!receiverRegistered) {
            ContextCompat.registerReceiver(
                this, detectionReceiver,
                IntentFilter(SoundDetectionService.ACTION_DETECTION),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            receiverRegistered = true
        }
        // 대화/설정 화면에서 돌아왔을 때 감지가 멈춰 있으면 다시 시작한다 (알림이 켜져 있을 때만).
        isAlarmOn = AppPrefs.isAlarmOn(this)
        SoundDetectionService.start(this)
    }

    override fun onPause() {
        super.onPause()
        if (receiverRegistered) {
            unregisterReceiver(detectionReceiver)
            receiverRegistered = false
        }
    }

    private companion object {
        const val REQ_PERMISSIONS = 200
        const val STATE_MODE = "state_mode"
    }
}
