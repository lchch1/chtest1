package com.example.yamnetwatchapp0913

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class ConversationListActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var btnBack: ImageView
    private lateinit var conversationAdapter: ConversationAdapter
    private val conversationList = mutableListOf<ConversationRecord>()
    private val gson = Gson()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conversation_list)

        btnBack = findViewById(R.id.btnBack)
        btnBack.setOnClickListener { finish() }

        recyclerView = findViewById(R.id.recyclerView)
        conversationAdapter = ConversationAdapter(conversationList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = conversationAdapter
    }

    override fun onResume() {
        super.onResume()
        // 상세 화면 등에서 돌아왔을 때도 최신 목록을 보여준다.
        loadConversations()
    }

    private fun loadConversations() {
        val sharedPref = getSharedPreferences("conversations", MODE_PRIVATE)
        conversationList.clear()

        val noTitle = getString(R.string.conversation_no_title)
        val recordIds = sharedPref.all.keys
            .filter { it.startsWith("title_") }
            .mapNotNull { it.substring(6).toLongOrNull() }

        recordIds.sortedDescending().forEach { recordId ->
            conversationList.add(
                ConversationRecord(
                    id = recordId,
                    title = sharedPref.getString("title_$recordId", noTitle) ?: noTitle,
                    messages = parseMessagesJson(sharedPref.getString("messages_$recordId", "[]") ?: "[]"),
                    timestamp = sharedPref.getLong("timestamp_$recordId", 0L)
                )
            )
        }
        conversationAdapter.notifyDataSetChanged()
    }

    private fun parseMessagesJson(json: String): List<ChatMessage> = try {
        val type = object : TypeToken<List<ChatMessage>>() {}.type
        gson.fromJson<List<ChatMessage>>(json, type) ?: emptyList()
    } catch (e: Exception) {
        e.printStackTrace()
        emptyList()
    }
}
