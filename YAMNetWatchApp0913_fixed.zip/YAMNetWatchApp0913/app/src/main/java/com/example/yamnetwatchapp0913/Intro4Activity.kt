package com.example.yamnetwatchapp0913

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

/** 온보딩 완료 화면 */
class Intro4Activity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_intro4)

        // 온보딩을 끝까지 마쳤을 때만 '최초 실행 완료'로 기록한다. (중간에 종료하면 다음 실행에 다시 안내)
        AppPrefs.setFirstRunDone(this)

        handler.postDelayed({
            startActivity(Intent(this, Splash2Activity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 2000L)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
