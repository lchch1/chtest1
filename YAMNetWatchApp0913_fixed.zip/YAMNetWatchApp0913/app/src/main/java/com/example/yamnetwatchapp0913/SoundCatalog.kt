package com.example.yamnetwatchapp0913

import android.content.Context
import androidx.annotation.StringRes

/**
 * 소리 설정 화면에 나열되는 소리 종류.
 * 각 모드 화면 이미지(ssssoundcontrolN.png)의 행 순서와 1:1 로 대응한다.
 */
enum class SoundKind(@StringRes val labelRes: Int) {
    DOORBELL(R.string.sound_doorbell),
    FIRE_ALARM(R.string.sound_fire_alarm),
    DOG(R.string.sound_dog),
    CAT(R.string.sound_cat),
    BABY_CRY(R.string.sound_baby_cry),
    KNOCK(R.string.sound_knock),
    SHOUT(R.string.sound_shout),
    GLASS_BREAK(R.string.sound_glass_break),
    HORN(R.string.sound_horn),
    CARD_TAG(R.string.sound_card_tag),
    SIREN(R.string.sound_siren),
    CAR_WARNING(R.string.sound_car_warning),
    SECURITY_ALARM(R.string.sound_security_alarm),
    PHONE_RING(R.string.sound_phone_ring),
    MACHINE(R.string.sound_machine),
    CRACK(R.string.sound_crack),
    IMPACT(R.string.sound_impact),
    SCHOOL_BELL(R.string.sound_school_bell)
}

/**
 * 앱의 모드. [sounds] 는 소리 설정 화면의 스위치 순서(sw1, sw2, ...)와 같다.
 */
enum class AppMode(val key: String, val sounds: List<SoundKind>) {
    HOME(
        "home",
        listOf(
            SoundKind.DOORBELL, SoundKind.FIRE_ALARM, SoundKind.DOG, SoundKind.CAT,
            SoundKind.BABY_CRY, SoundKind.KNOCK, SoundKind.SHOUT
        )
    ),
    DRIVING(
        "driving",
        listOf(
            SoundKind.HORN, SoundKind.SIREN, SoundKind.CAR_WARNING,
            SoundKind.CAT, SoundKind.BABY_CRY, SoundKind.DOG
        )
    ),
    WORK(
        "work",
        listOf(
            SoundKind.SHOUT, SoundKind.SECURITY_ALARM, SoundKind.PHONE_RING,
            SoundKind.MACHINE, SoundKind.CRACK, SoundKind.IMPACT
        )
    ),
    TRANSIT(
        "transit",
        listOf(
            SoundKind.FIRE_ALARM, SoundKind.GLASS_BREAK, SoundKind.HORN,
            SoundKind.CARD_TAG, SoundKind.BABY_CRY, SoundKind.DOG
        )
    ),
    SCHOOL(
        "school",
        listOf(
            SoundKind.SHOUT, SoundKind.SECURITY_ALARM, SoundKind.PHONE_RING,
            SoundKind.MACHINE, SoundKind.CRACK, SoundKind.IMPACT, SoundKind.SCHOOL_BELL
        )
    ),
    MYMENU(
        "mymenu",
        listOf(
            SoundKind.DOORBELL, SoundKind.FIRE_ALARM, SoundKind.DOG,
            SoundKind.SHOUT, SoundKind.BABY_CRY, SoundKind.HORN
        )
    );

    companion object {
        fun fromKey(key: String?): AppMode? = values().firstOrNull { it.key == key }
    }
}

/**
 * 소리별 알림 스위치 저장소.
 *
 * 이전에는 모드마다 SharedPreferences 파일과 키 이름이 제각각이었고(`dog2_settings`/`Ssw6_state` ...),
 * 값도 R.id 정수를 키로 쓰는 곳이 있어 빌드가 바뀌면 저장값을 못 찾을 수 있었다.
 * 이제 `sound_switches_<모드>` 파일에 `<소리 종류 이름>` 키로 저장한다.
 */
object SoundPrefs {

    private fun prefs(context: Context, mode: AppMode) =
        context.applicationContext.getSharedPreferences("sound_switches_${mode.key}", Context.MODE_PRIVATE)

    fun isOn(context: Context, mode: AppMode, kind: SoundKind): Boolean =
        prefs(context, mode).getBoolean(kind.name, true)

    fun setOn(context: Context, mode: AppMode, kind: SoundKind, on: Boolean) {
        prefs(context, mode).edit().putBoolean(kind.name, on).apply()
    }

    /** 온보딩 질문(반려동물/아기) 답변을 해당 소리가 있는 **모든 모드**에 반영한다. */
    fun setEverywhere(context: Context, kinds: Collection<SoundKind>, on: Boolean) {
        for (mode in AppMode.values()) {
            for (kind in kinds) {
                if (kind in mode.sounds) setOn(context, mode, kind, on)
            }
        }
    }

    /**
     * 감지 서비스가 참조하는 값.
     * 현재 실제로 감지하는 소리는 초인종·아기 울음 두 가지뿐이고, 기존 동작과 동일하게
     * 모든 모드에서 **홈 모드의 스위치**를 따른다.
     */
    fun isDetectionEnabled(context: Context, kind: SoundKind): Boolean =
        isOn(context, AppMode.HOME, kind)
}

/** 앱 공통 설정 (첫 실행 여부, 알림 on/off, 모드 사용 여부) */
object AppPrefs {
    private const val APP = "app_prefs"
    private const val MODES = "mode_prefs"
    private const val KEY_FIRST_RUN = "is_first_run"
    private const val KEY_ALARM_ON = "alarm_on"

    private fun app(context: Context) =
        context.applicationContext.getSharedPreferences(APP, Context.MODE_PRIVATE)

    private fun modes(context: Context) =
        context.applicationContext.getSharedPreferences(MODES, Context.MODE_PRIVATE)

    fun isFirstRun(context: Context): Boolean = app(context).getBoolean(KEY_FIRST_RUN, true)

    fun setFirstRunDone(context: Context) {
        app(context).edit().putBoolean(KEY_FIRST_RUN, false).apply()
    }

    /** 메인 화면의 알림 스위치. 서비스/다른 화면이 같은 값을 보도록 저장한다. */
    fun isAlarmOn(context: Context): Boolean = app(context).getBoolean(KEY_ALARM_ON, true)

    fun setAlarmOn(context: Context, on: Boolean) {
        app(context).edit().putBoolean(KEY_ALARM_ON, on).apply()
    }

    /** 온보딩에서 선택한 모드인지. '내 모드'는 항상 사용 가능하다. */
    fun isModeEnabled(context: Context, mode: AppMode): Boolean =
        if (mode == AppMode.MYMENU) true else modes(context).getBoolean("${mode.key}_enabled", true)

    fun setModesEnabled(context: Context, enabled: Map<AppMode, Boolean>) {
        val editor = modes(context).edit()
        enabled.forEach { (mode, on) -> editor.putBoolean("${mode.key}_enabled", on) }
        editor.apply()
    }
}
