package com.example.yamnetwatchapp0913

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioRecord
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.Tasks
import com.google.android.gms.wearable.Wearable
import org.tensorflow.lite.task.audio.classifier.AudioClassifier
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * 주변 소리(초인종·아기 울음)를 계속 감지하는 Foreground Service.
 *
 * 이전에는 MainActivity 안의 Handler(메인 스레드)에서 500ms 마다 TFLite 추론을 돌렸고,
 * 다른 화면들이 `MainActivity.mainActivityInstance`(static Activity 참조)로 감지를 켜고 껐다.
 * 그 결과 ① 추론이 UI 스레드를 막아 ANR 위험, ② 화면이 꺼지거나 앱이 백그라운드로 가면 감지 중단,
 * ③ Activity 메모리 누수가 있었다. 이 서비스는 세 문제를 함께 해결한다.
 *
 *  - 추론은 별도 HandlerThread 에서 실행한다.
 *  - 감지 결과는 (1) 열려 있는 MainActivity 로 순서 브로드캐스트, (2) 처리되지 않았다면 헤드업 알림,
 *    (3) 연결된 워치로 메시지 — 로 전달한다.
 *  - 알림(AppPrefs.isAlarmOn)이 꺼져 있거나 마이크 권한이 없으면 시작하지 않는다.
 */
class SoundDetectionService : Service() {

    companion object {
        const val ACTION_DETECTION = "com.example.yamnetwatchapp0913.action.DETECTION"
        const val EXTRA_TYPE = "extra_type"
        const val TYPE_DOORBELL = "doorbell"
        const val TYPE_BABY_CRY = "baby_cry"

        private const val TAG = "SoundDetectionService"
        private const val SERVICE_CHANNEL_ID = "sound_detection_channel"
        private const val ALERT_CHANNEL_ID = "sound_alert_channel"
        private const val SERVICE_NOTI_ID = 1001
        private const val ALERT_NOTI_ID = 1002
        private const val MODEL_PATH = "1.tflite"
        private const val THRESHOLD = 0.4f
        private const val INTERVAL_MS = 500L
        private const val COOLDOWN_MS = 3000L            // 같은 알림 연속 발생 방지
        private const val WAKE_LOCK_LEASE_MS = 10 * 60 * 1000L

        private const val DOORBELL_PATH = "/doorbell_alert"
        private const val BABY_CRY_PATH = "/baby_cry_alert"

        private val DOORBELL_WORDS = listOf("Doorbell", "Bell", "Ring", "Chime", "Ding", "Dinging", "Knock")
        private val BABY_WORDS = listOf("Baby", "Cry", "Crying", "Infant", "Wail", "Whimper", "Weep")

        /**
         * 감지 서비스 시작.
         * 메인 화면의 알림 스위치가 꺼져 있거나 마이크 권한이 없으면 아무것도 하지 않는다.
         * Android 12+ 의 백그라운드 시작 제한으로 예외가 날 수 있어 방어적으로 처리한다.
         */
        fun start(context: Context) {
            val app = context.applicationContext
            if (!AppPrefs.isAlarmOn(app)) return
            if (ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) !=
                PackageManager.PERMISSION_GRANTED
            ) return
            try {
                ContextCompat.startForegroundService(app, Intent(app, SoundDetectionService::class.java))
            } catch (e: Exception) {
                Log.e(TAG, "서비스 시작 실패(백그라운드 제한 가능): ${e.message}")
            }
        }

        /** 감지 서비스 중지 (마이크를 대화/단어 인식 화면에 양보할 때) */
        fun stop(context: Context) {
            val app = context.applicationContext
            app.stopService(Intent(app, SoundDetectionService::class.java))
        }
    }

    private var classifier: AudioClassifier? = null
    private var audioRecord: AudioRecord? = null
    private var workerThread: HandlerThread? = null
    private var workerHandler: Handler? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val watchExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    @Volatile private var running = false
    private var lastDoorbellAt = 0L
    private var lastBabyAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // 마이크 권한이 없으면 마이크 Foreground Service 시작 시 크래시(Android 14+)하므로 방어
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startForegroundCompat()
        } catch (e: Exception) {
            Log.e(TAG, "startForeground 실패: ${e.message}")
            stopSelf()
            return START_NOT_STICKY
        }
        startDetection()
        return START_STICKY
    }

    // ---------------------------------------------------------------- 감지 루프

    private fun startDetection() {
        if (running) return
        try {
            val clf = classifier ?: AudioClassifier.createFromFile(this, MODEL_PATH).also { classifier = it }
            val record = clf.createAudioRecord().apply { startRecording() }
            audioRecord = record
            running = true

            val thread = HandlerThread("sound-detect").also { it.start() }
            workerThread = thread
            val handler = Handler(thread.looper)
            workerHandler = handler

            val task = object : Runnable {
                override fun run() {
                    if (!running) return
                    renewWakeLock()
                    classifyOnce(clf, record)
                    if (running) handler.postDelayed(this, INTERVAL_MS)
                }
            }
            handler.post(task)
            Log.d(TAG, "감지 시작")
        } catch (e: Exception) {
            Log.e(TAG, "감지 시작 실패: ${e.message}", e)
            stopDetection()
            stopSelf()
        }
    }

    private fun classifyOnce(clf: AudioClassifier, record: AudioRecord) {
        try {
            val tensor = clf.createInputTensorAudio().apply { load(record) }
            val categories = clf.classify(tensor).flatMap { it.categories }

            val doorbell = categories.any { c -> c.score >= THRESHOLD && DOORBELL_WORDS.any { c.label.contains(it, true) } }
            val baby = categories.any { c -> c.score >= THRESHOLD && BABY_WORDS.any { c.label.contains(it, true) } }

            val now = System.currentTimeMillis()
            if (doorbell && now - lastDoorbellAt > COOLDOWN_MS &&
                SoundPrefs.isDetectionEnabled(this, SoundKind.DOORBELL)
            ) {
                lastDoorbellAt = now
                onDetected(TYPE_DOORBELL, DOORBELL_PATH)
            } else if (baby && now - lastBabyAt > COOLDOWN_MS &&
                SoundPrefs.isDetectionEnabled(this, SoundKind.BABY_CRY)
            ) {
                lastBabyAt = now
                onDetected(TYPE_BABY_CRY, BABY_CRY_PATH)
            }
        } catch (e: Exception) {
            Log.e(TAG, "분류 오류: ${e.message}")
        }
    }

    // ---------------------------------------------------------------- 결과 전달

    private fun onDetected(type: String, watchPath: String) {
        // 1) 열려 있는 MainActivity 가 있으면 팝업을 띄운다 (처리하면 RESULT_OK 로 응답).
        //    2) 아무도 처리하지 않았다면(앱이 백그라운드/화면 꺼짐) 헤드업 알림을 띄운다.
        val intent = Intent(ACTION_DETECTION).apply {
            setPackage(packageName)
            putExtra(EXTRA_TYPE, type)
        }
        val finalReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (resultCode != Activity.RESULT_OK) postAlertNotification(type)
            }
        }
        sendOrderedBroadcast(intent, null, finalReceiver, null, Activity.RESULT_CANCELED, null, null)

        // 3) 워치 — 네트워크 대기가 감지 루프를 막지 않도록 별도 스레드에서 보낸다.
        watchExecutor.execute { sendAlertToWatch(watchPath, type) }
    }

    private fun postAlertNotification(type: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) return

        val tap = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_TYPE, type)
        }
        val pendingIntent = PendingIntent.getActivity(
            this, type.hashCode(), tap, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val title = if (type == TYPE_DOORBELL) R.string.noti_doorbell_title else R.string.noti_baby_title
        val noti = NotificationCompat.Builder(this, ALERT_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_alert)
            .setContentTitle(getString(title))
            .setContentText(getString(R.string.noti_alert_text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()
        getSystemService(NotificationManager::class.java).notify(ALERT_NOTI_ID, noti)
    }

    private fun sendAlertToWatch(path: String, payload: String) {
        try {
            val nodes = Tasks.await(Wearable.getNodeClient(this).connectedNodes, 5, TimeUnit.SECONDS)
            val client = Wearable.getMessageClient(this)
            nodes.forEach { client.sendMessage(it.id, path, payload.toByteArray()) }
        } catch (e: Exception) {
            Log.e(TAG, "워치 알림 전송 실패: ${e.message}")
        }
    }

    // ---------------------------------------------------------------- 정리

    private fun stopDetection() {
        running = false
        // 작업 스레드를 먼저 끝낸 뒤 AudioRecord 를 해제해야 해제 중 read 하는 경합이 없다.
        val thread = workerThread
        workerHandler?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        try { thread?.join(1000) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        workerThread = null
        workerHandler = null

        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (e: Exception) {
            Log.e(TAG, "오디오 정지 오류: ${e.message}")
        }
        audioRecord = null
        releaseWakeLock()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopDetection()
        classifier?.close()
        classifier = null
        watchExecutor.shutdown()
        Log.d(TAG, "감지 중지")
    }

    // ---------------------------------------------------------------- WakeLock (화면이 꺼져도 감지 유지)

    private fun renewWakeLock() {
        val lock = wakeLock ?: getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "hearo:sound-detect")
            .apply { setReferenceCounted(false) }
            .also { wakeLock = it }
        // 임대 방식: 루프가 살아 있는 동안만 계속 연장되고, 루프가 죽으면 스스로 해제된다.
        lock.acquire(WAKE_LOCK_LEASE_MS)
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.takeIf { it.isHeld }?.release()
        } catch (_: Exception) {
        }
        wakeLock = null
    }

    // ---------------------------------------------------------------- 알림 채널 / 포그라운드 알림

    private fun startForegroundCompat() {
        val noti: Notification = NotificationCompat.Builder(this, SERVICE_CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.noti_service_text))
            .setSmallIcon(R.drawable.ic_stat_alert)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(SERVICE_NOTI_ID, noti, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(SERVICE_NOTI_ID, noti)
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(
                SERVICE_CHANNEL_ID, getString(R.string.noti_channel_service), NotificationManager.IMPORTANCE_LOW
            ).apply { description = getString(R.string.noti_channel_service_desc) }
        )
        nm.createNotificationChannel(
            NotificationChannel(
                ALERT_CHANNEL_ID, getString(R.string.noti_channel_alert), NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = getString(R.string.noti_channel_alert_desc)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 500)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
        )
    }
}
