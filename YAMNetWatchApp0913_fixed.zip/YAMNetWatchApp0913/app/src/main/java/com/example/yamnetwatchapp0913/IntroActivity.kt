package com.example.yamnetwatchapp0913

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** 온보딩 1단계: 사용할 모드 선택 */
class IntroActivity : AppCompatActivity() {

    private val buttons = linkedMapOf(
        R.id.introhome to AppMode.HOME,
        R.id.introdriving to AppMode.DRIVING,
        R.id.introwork to AppMode.WORK,
        R.id.introtransit to AppMode.TRANSIT,
        R.id.introschool to AppMode.SCHOOL
    )

    // 모드별 (선택됨, 선택 안 됨) 이미지
    private val images = mapOf(
        AppMode.HOME to (R.drawable.chooseintrohome to R.drawable.introhome),
        AppMode.DRIVING to (R.drawable.chooseintrodriving to R.drawable.introdriving),
        AppMode.WORK to (R.drawable.chooseintrowork to R.drawable.introwork),
        AppMode.TRANSIT to (R.drawable.chooseintrotransit to R.drawable.introtransit),
        AppMode.SCHOOL to (R.drawable.chooseintroschool to R.drawable.introschool)
    )

    private val selected = mutableSetOf<AppMode>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_intro)

        savedInstanceState?.getStringArrayList(STATE_SELECTED)
            ?.mapNotNull { AppMode.fromKey(it) }
            ?.let { selected.addAll(it) }

        buttons.forEach { (id, mode) ->
            val view = findViewById<ImageView>(id)
            render(view, mode)
            view.setOnClickListener {
                if (!selected.add(mode)) selected.remove(mode)
                render(view, mode)
            }
        }

        findViewById<ImageView>(R.id.intronextbutton).setOnClickListener { goNext() }
    }

    private fun render(view: ImageView, mode: AppMode) {
        val (on, off) = images.getValue(mode)
        view.setImageResource(if (mode in selected) on else off)
    }

    private fun goNext() {
        if (selected.isEmpty()) {
            // 모드가 하나도 없으면 메인 화면에서 아무것도 선택할 수 없게 되므로 막는다.
            Toast.makeText(this, R.string.intro_select_mode, Toast.LENGTH_SHORT).show()
            return
        }
        AppPrefs.setModesEnabled(this, buttons.values.associateWith { it in selected })
        startActivity(Intent(this, Intro2Activity::class.java))
        finish()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putStringArrayList(STATE_SELECTED, ArrayList(selected.map { it.key }))
    }

    private companion object {
        const val STATE_SELECTED = "state_selected_modes"
    }
}
