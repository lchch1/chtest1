package com.example.yamnetwatchapp0913

class SoundSetting3Activity : BaseSoundSettingActivity() {
    override val layoutResId: Int get() = R.layout.activity_soundsetting3
    override val mode: AppMode get() = AppMode.DRIVING
}
