package com.example.yamnetwatchapp0913

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ConversationAdapter(private val conversations: List<ConversationRecord>) :
    RecyclerView.Adapter<ConversationAdapter.ViewHolder>() {

    // 항목마다 만들지 않고 어댑터에서 한 번만 만든다.
    private val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREAN)

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val titleView: TextView = view.findViewById(R.id.tvTitle)
        private val dateView: TextView = view.findViewById(R.id.tvDate)
        private val messageCountView: TextView = view.findViewById(R.id.tvMessageCount)

        fun bind(record: ConversationRecord) {
            titleView.text = record.title
            dateView.text = formatter.format(Date(record.timestamp))
            messageCountView.text = itemView.context.getString(
                R.string.conversation_message_count, record.messages.size
            )

            itemView.setOnClickListener {
                val intent = Intent(itemView.context, ConversationDetailActivity::class.java)
                    .putExtra("recordId", record.id)
                    .putExtra("title", record.title)
                itemView.context.startActivity(intent)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_conversation, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(conversations[position])
    }

    override fun getItemCount(): Int = conversations.size
}
