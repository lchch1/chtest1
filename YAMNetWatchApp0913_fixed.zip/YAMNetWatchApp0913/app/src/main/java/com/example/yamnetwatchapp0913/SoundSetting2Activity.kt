package com.example.yamnetwatchapp0913

class SoundSetting2Activity : BaseSoundSettingActivity() {
    override val layoutResId: Int get() = R.layout.activity_soundsetting2
    override val mode: AppMode get() = AppMode.TRANSIT
}
