package com.example.yamnetwatchapp0913

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class ConversationDetailActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var btnBack: ImageView
    private lateinit var tvTitle: TextView
    private lateinit var chatAdapter: ChatAdapter
    private val messageList = mutableListOf<ChatMessage>()
    private val gson = Gson()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conversation_detail)

        btnBack = findViewById(R.id.btnBack)
        tvTitle = findViewById(R.id.tvTitle)
        recyclerView = findViewById(R.id.recyclerView)

        // 시스템 뒤로가기는 기본 동작(finish)과 같으므로 별도 콜백이 필요 없다.
        btnBack.setOnClickListener { finish() }

        chatAdapter = ChatAdapter(messageList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = chatAdapter

        val recordId = intent.getLongExtra("recordId", 0L)
        tvTitle.text = intent.getStringExtra("title") ?: getString(R.string.chat_title)

        loadConversationDetail(recordId)
    }

    private fun loadConversationDetail(recordId: Long) {
        val sharedPref = getSharedPreferences("conversations", MODE_PRIVATE)
        val messagesJson = sharedPref.getString("messages_$recordId", "[]") ?: "[]"

        messageList.clear()
        messageList.addAll(parseMessagesJson(messagesJson))
        chatAdapter.notifyDataSetChanged()

        if (messageList.isNotEmpty()) recyclerView.scrollToPosition(messageList.size - 1)
    }

    private fun parseMessagesJson(json: String): List<ChatMessage> = try {
        val type = object : TypeToken<List<ChatMessage>>() {}.type
        gson.fromJson<List<ChatMessage>>(json, type) ?: emptyList()
    } catch (e: Exception) {
        e.printStackTrace()
        emptyList()
    }
}
