package com.example.yamnetwatchapp0913

class SoundSetting6Activity : BaseSoundSettingActivity() {
    override val layoutResId: Int get() = R.layout.activity_soundsetting6
    override val mode: AppMode get() = AppMode.MYMENU
}
