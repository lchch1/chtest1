package com.example.yamnetwatchapp0913

import android.annotation.SuppressLint
import android.view.MotionEvent
import android.view.View

/**
 * 누르는 동안 투명도를 낮추는 눌림 효과.
 *
 * 이전에는 `setOnTouchListener` 가 ACTION_DOWN/UP 을 직접 소비(true 반환)해서 일반 클릭이 발생하지 않았고,
 * 그 결과 TalkBack(접근성) 이중 탭이나 키보드로는 버튼을 누를 수 없었다.
 * 여기서는 항상 false 를 반환해 이벤트를 소비하지 않으므로 `setOnClickListener` 가 정상 동작한다.
 */
@SuppressLint("ClickableViewAccessibility")
fun View.setPressAlphaFeedback(pressedAlpha: Float = 0.7f) {
    setOnTouchListener { v, event ->
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.alpha = pressedAlpha
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.alpha = 1f
        }
        false
    }
}
