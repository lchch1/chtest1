package com.example.yamnetwatchapp0913

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.Locale

/**
 * 청각장애인 ↔ 상대방 대화 화면.
 *  - 내가 입력한 글은 TTS 로 읽어 주고, 상대방 말은 STT 로 글자로 바꿔 보여준다.
 *  - 마이크를 쓰는 동안에는 소리 감지 서비스를 잠시 멈춘다.
 */
class ChatActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var recyclerView: RecyclerView
    private lateinit var etMessage: EditText
    private lateinit var btnSend: Button
    private lateinit var btnSpeak: Button
    private lateinit var btnRecordVoice: Button
    private lateinit var btnBack: ImageView
    private lateinit var btnSave: Button
    private lateinit var btnList: Button
    private lateinit var btnUnderstand: Button
    private lateinit var guidanceOverlay: FrameLayout

    private lateinit var chatAdapter: ChatAdapter
    private val messageList = mutableListOf<ChatMessage>()

    private lateinit var textToSpeech: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var speechIntent: Intent

    private var isRecording = false
    private var lastMyMessage: String = ""
    private var isTtsReady = false

    private val gson = Gson()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        // 마이크를 음성 인식에 양보한다. (화면을 나갈 때 다시 시작)
        SoundDetectionService.stop(this)

        initializeViews()
        restoreMessages(savedInstanceState)
        setupRecyclerView()
        setupButtonListeners()
        initializeSpeechIntent()
        checkAndRequestPermissions()

        textToSpeech = TextToSpeech(this, this)
    }

    private fun initializeViews() {
        btnBack = findViewById(R.id.btnBack)
        guidanceOverlay = findViewById(R.id.guidanceOverlay)
        btnUnderstand = findViewById(R.id.btnUnderstand)
        recyclerView = findViewById(R.id.recyclerView)
        etMessage = findViewById(R.id.etMessage)
        btnSend = findViewById(R.id.btnSend)
        btnSpeak = findViewById(R.id.btnSpeak)
        btnRecordVoice = findViewById(R.id.btnRecordVoice)
        btnSave = findViewById(R.id.btnSave)
        btnList = findViewById(R.id.btnList)
    }

    private fun setupRecyclerView() {
        chatAdapter = ChatAdapter(messageList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = chatAdapter
        if (messageList.isNotEmpty()) recyclerView.scrollToPosition(messageList.size - 1)
    }

    private fun setupButtonListeners() {
        btnBack.setOnClickListener { finish() }
        btnUnderstand.setOnClickListener {
            guidanceOverlay.visibility = View.GONE
            textToSpeech.stop()
        }
        btnSend.setOnClickListener { sendMessage() }
        btnSpeak.setOnClickListener { replayMessage() }
        btnRecordVoice.setOnClickListener { toggleVoiceRecording() }
        btnSave.setOnClickListener { showSaveDialog() }
        btnList.setOnClickListener { startActivity(Intent(this, ConversationListActivity::class.java)) }
    }

    // ------------------------------------------------------------------ TTS

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        when (textToSpeech.setLanguage(Locale.KOREAN)) {
            TextToSpeech.LANG_MISSING_DATA -> promptInstallTtsData()
            TextToSpeech.LANG_NOT_SUPPORTED -> {
                textToSpeech.language = Locale.ENGLISH
                isTtsReady = true
            }
            else -> isTtsReady = true
        }
        // 대화 시작 안내("저는 청각장애인입니다…")를 상대방에게 읽어 준다.
        if (isTtsReady && guidanceOverlay.visibility == View.VISIBLE) speakGuidance()
    }

    private fun promptInstallTtsData() {
        try {
            startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA))
        } catch (e: ActivityNotFoundException) {
            // 설치 화면을 처리하는 앱이 없는 기기에서는 이전처럼 크래시하지 않고 안내만 한다.
            Toast.makeText(this, R.string.tts_data_missing, Toast.LENGTH_LONG).show()
        }
    }

    private fun speakGuidance() {
        textToSpeech.setPitch(1.0f)
        textToSpeech.setSpeechRate(1.0f)
        textToSpeech.speak(getString(R.string.guidance_tts), TextToSpeech.QUEUE_FLUSH, null, "guidanceID")
    }

    private fun playTTS(text: String) {
        if (!isTtsReady) return
        try {
            if (textToSpeech.isSpeaking) textToSpeech.stop()
            textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
        } catch (e: Exception) {
            Log.e(TAG, "TTS 재생 오류: ${e.message}")
        }
    }

    // ------------------------------------------------------------------ 메시지

    private fun sendMessage() {
        val messageText = etMessage.text.toString().trim()
        if (messageText.isEmpty()) return
        chatAdapter.addMessage(ChatMessage(messageText, isMine = true))
        lastMyMessage = messageText
        etMessage.text.clear()
        recyclerView.scrollToPosition(messageList.size - 1)
        playTTS(messageText)
    }

    private fun replayMessage() {
        if (lastMyMessage.isNotEmpty()) playTTS(lastMyMessage)
    }

    // ------------------------------------------------------------------ STT

    private fun initializeSpeechIntent() {
        speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 5000L)
        }
    }

    private fun toggleVoiceRecording() {
        if (isRecording) {
            stopSpeech()
            resetRecordButton()
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            checkAndRequestPermissions()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, R.string.speech_not_available, Toast.LENGTH_LONG).show()
            return
        }
        textToSpeech.stop() // 내 TTS 소리를 상대방 말로 잘못 인식하지 않도록
        startSpeech()
        btnRecordVoice.text = "⏹"
        btnRecordVoice.contentDescription = getString(R.string.cd_chat_record_stop)
        btnRecordVoice.alpha = 0.7f
        isRecording = true
    }

    private fun startSpeech() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(speechListener)
                startListening(speechIntent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "음성 인식 시작 실패: ${e.message}", e)
            resetRecordButton()
        }
    }

    private fun stopSpeech() {
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            Log.e(TAG, "음성 인식 중지 오류: ${e.message}")
        }
    }

    private val speechListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) {
            Log.e(TAG, "STT 에러: $error")
            resetRecordButton()
        }

        override fun onResults(results: Bundle) {
            val list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (!list.isNullOrEmpty()) {
                chatAdapter.addMessage(ChatMessage(list[0], isMine = false))
                recyclerView.scrollToPosition(messageList.size - 1)
            }
            resetRecordButton()
        }

        override fun onPartialResults(partialResults: Bundle) {}
        override fun onEvent(eventType: Int, params: Bundle) {}
    }

    private fun resetRecordButton() {
        btnRecordVoice.text = "🎤"
        btnRecordVoice.contentDescription = getString(R.string.cd_chat_record)
        btnRecordVoice.alpha = 1.0f
        isRecording = false
    }

    // ------------------------------------------------------------------ 저장

    private fun showSaveDialog() {
        if (messageList.isEmpty()) {
            Toast.makeText(this, R.string.chat_nothing_to_save, Toast.LENGTH_SHORT).show()
            return
        }
        val editText = EditText(this).apply {
            hint = getString(R.string.save_dialog_hint)
            setPadding(40, 20, 40, 20)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.save_dialog_title)
            .setView(editText)
            .setPositiveButton(R.string.common_save) { _, _ ->
                val title = editText.text.toString().trim()
                if (title.isNotEmpty()) saveConversation(title)
            }
            .setNegativeButton(R.string.common_cancel, null)
            .show()
    }

    private fun saveConversation(title: String) {
        val recordId = System.currentTimeMillis()
        getSharedPreferences("conversations", MODE_PRIVATE).edit()
            .putString("title_$recordId", title)
            .putString("messages_$recordId", gson.toJson(messageList))
            .putLong("timestamp_$recordId", recordId)
            .apply()
        Toast.makeText(this, R.string.chat_saved, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------ 상태 보존 (프로세스 종료 대비)

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(STATE_MESSAGES, gson.toJson(messageList))
        outState.putString(STATE_LAST_MY, lastMyMessage)
    }

    private fun restoreMessages(state: Bundle?) {
        val json = state?.getString(STATE_MESSAGES) ?: return
        try {
            val type = object : TypeToken<List<ChatMessage>>() {}.type
            gson.fromJson<List<ChatMessage>>(json, type)?.let { messageList.addAll(it) }
        } catch (e: Exception) {
            Log.e(TAG, "대화 복원 실패: ${e.message}")
        }
        lastMyMessage = state.getString(STATE_LAST_MY).orEmpty()
        guidanceOverlay.visibility = View.GONE // 이미 안내를 본 뒤에 복원된 경우
    }

    // ------------------------------------------------------------------ 권한 / 수명주기

    private fun checkAndRequestPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), PERMISSION_REQUEST_CODE)
        }
    }

    override fun onPause() {
        super.onPause()
        if (isRecording) {
            stopSpeech()
            resetRecordButton()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // 대화 화면을 닫으면 소리 감지를 다시 시작한다 (알림이 켜져 있을 때만 시작됨)
        SoundDetectionService.start(this)
        textToSpeech.stop()
        textToSpeech.shutdown()
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    private companion object {
        const val PERMISSION_REQUEST_CODE = 100
        const val TAG = "ChatActivity"
        const val STATE_MESSAGES = "state_messages"
        const val STATE_LAST_MY = "state_last_my"
    }
}
