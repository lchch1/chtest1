package com.example.yamnetwatchapp0913

class SoundSettingActivity : BaseSoundSettingActivity() {
    override val layoutResId: Int get() = R.layout.activity_soundsetting
    override val mode: AppMode get() = AppMode.HOME
}
