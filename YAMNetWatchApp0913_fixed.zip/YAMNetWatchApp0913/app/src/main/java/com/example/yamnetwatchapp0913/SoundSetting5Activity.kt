package com.example.yamnetwatchapp0913

class SoundSetting5Activity : BaseSoundSettingActivity() {
    override val layoutResId: Int get() = R.layout.activity_soundsetting5
    override val mode: AppMode get() = AppMode.SCHOOL
}
