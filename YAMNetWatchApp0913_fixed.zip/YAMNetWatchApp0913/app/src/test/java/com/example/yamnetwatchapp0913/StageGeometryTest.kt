package com.example.yamnetwatchapp0913

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.random.Random

/**
 * DesignStageLayout 의 배율/정렬 계산(StageGeometry) 검증.
 * Android 에 의존하지 않으므로 `./gradlew :app:testDebugUnitTest` 로 바로 실행된다.
 */
class StageGeometryTest {

    private val density = 3f

    /** 화면(dp)에 캔버스를 맞춘 결과를 px 로 계산하는 헬퍼 */
    private class Sim(val d: Float, screenWdp: Float, screenHdp: Float) {
        val screenW = (screenWdp * d).toInt()
        val screenH = (screenHdp * d).toInt()
        val g = StageGeometry(412f * d, 917f * d).also { it.fit(screenW, screenH) }

        /** 디자인 dp 사각형 → 화면 px [left, top, right, bottom] */
        fun rect(leftDp: Float, topDp: Float, wDp: Float, hDp: Float): IntArray {
            val l = g.left((leftDp * d).toInt())
            val t = g.top((topDp * d).toInt())
            return intArrayOf(l, t, l + g.scaled((wDp * d).toInt()), t + g.scaled((hDp * d).toInt()))
        }
    }

    private val screens = listOf(
        "16:9 폰 360x640" to (360f to 640f),
        "폰 360x800" to (360f to 800f),
        "폰 393x852" to (393f to 852f),
        "폰 412x915" to (412f to 915f),
        "접힌 폴더블 280x653" to (280f to 653f),
        "펼친 폴더블 673x841" to (673f to 841f),
        "태블릿 800x1280" to (800f to 1280f),
        "태블릿 가로 1280x800" to (1280f to 800f),
        "폰 가로 800x360" to (800f to 360f),
        "분할 화면 412x450" to (412f to 450f)
    )

    @Test
    fun designSizedScreen_isIdentity() {
        val s = Sim(density, 412f, 917f)
        assertEquals(1f, s.g.scale, 0.001f)
        val r = s.rect(131f, 172f, 134f, 147f)
        assertEquals((131 * density).toInt(), r[0])
        assertEquals((172 * density).toInt(), r[1])
    }

    @Test
    fun canvasAlwaysFitsInsideScreen_andIsCentered() {
        for ((name, wh) in screens) {
            val s = Sim(density, wh.first, wh.second)
            val c = s.rect(0f, 0f, 412f, 917f)
            assertTrue("$name: 캔버스가 화면 밖으로 잘림 ${c.toList()}",
                c[0] >= -1 && c[1] >= -1 && c[2] <= s.screenW + 1 && c[3] <= s.screenH + 1)
            assertEquals("$name: 가로 중앙", s.screenW / 2f, (c[0] + c[2]) / 2f, 2f)
            assertEquals("$name: 세로 중앙", s.screenH / 2f, (c[1] + c[3]) / 2f, 2f)
            // 가능한 가장 큰 배율: 가로 또는 세로 중 한쪽은 화면을 꽉 채운다
            val fillsWidth = abs((c[2] - c[0]) - s.screenW) <= 2
            val fillsHeight = abs((c[3] - c[1]) - s.screenH) <= 2
            assertTrue("$name: 배율이 최대가 아님", fillsWidth || fillsHeight)
        }
    }

    @Test
    fun relativePositionsDoNotDriftAcrossScreenSizes() {
        // 노란 원 대비 아이콘의 상대 위치가 모든 화면에서 같아야 배경 그림과 어긋나지 않는다.
        fun rel(s: Sim): List<Float> {
            val circle = s.rect(78f, 129f, 256f, 256f)
            val work = s.rect(337f, 170f, 43f, 55f)
            val gear = s.rect(339f, 841f, 56f, 56f)
            val cw = (circle[2] - circle[0]).toFloat()
            val ch = (circle[3] - circle[1]).toFloat()
            return listOf(
                (work[0] - circle[0]) / cw, (work[1] - circle[1]) / ch,
                (gear[0] - circle[0]) / cw, (gear[1] - circle[1]) / ch
            )
        }
        val base = rel(Sim(density, 412f, 917f))
        for ((name, wh) in screens) {
            val r = rel(Sim(density, wh.first, wh.second))
            base.indices.forEach { assertEquals("$name [$it]", base[it], r[it], 0.02f) }
        }
    }

    @Test
    fun randomScreens_neverClip() {
        val rnd = Random(7)
        repeat(2000) {
            val w = rnd.nextInt(200, 1600).toFloat()
            val h = rnd.nextInt(200, 2400).toFloat()
            val d = listOf(1.5f, 2f, 2.625f, 3f, 3.5f).random(rnd)
            val s = Sim(d, w, h)
            val c = s.rect(0f, 0f, 412f, 917f)
            assertTrue("${w}x$h@$d 잘림 ${c.toList()}",
                c[0] >= -2 && c[1] >= -2 && c[2] <= s.screenW + 2 && c[3] <= s.screenH + 2)
        }
    }

    @Test
    fun negativeMargins_bleedOutsideTheCanvas() {
        val r = Sim(density, 412f, 917f).rect(-106f, -230f, 838f, 838f)
        assertTrue(r[0] < 0 && r[1] < 0)
    }
}
