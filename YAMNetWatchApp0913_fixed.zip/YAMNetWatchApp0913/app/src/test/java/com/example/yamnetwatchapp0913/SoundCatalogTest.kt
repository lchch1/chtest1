package com.example.yamnetwatchapp0913

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * 모드별 소리 목록은 `ssssoundcontrolN.png` 이미지의 행 순서와 같아야 한다.
 * (스위치 sw1..swN 이 어떤 소리인지가 이 순서로 결정되므로, 이미지를 바꾸면 이 테스트도 같이 고쳐야 한다)
 */
class SoundCatalogTest {

    @Test
    fun soundCountPerMode_matchesLayouts() {
        // 각 모드 레이아웃에 있는 스위치(sw1..) 개수
        assertEquals(7, AppMode.HOME.sounds.size)
        assertEquals(6, AppMode.TRANSIT.sounds.size)
        assertEquals(6, AppMode.DRIVING.sounds.size)
        assertEquals(6, AppMode.WORK.sounds.size)
        assertEquals(7, AppMode.SCHOOL.sounds.size)
        assertEquals(6, AppMode.MYMENU.sounds.size)
    }

    @Test
    fun home_rowOrder_matchesImage() {
        assertEquals(
            listOf(
                SoundKind.DOORBELL, SoundKind.FIRE_ALARM, SoundKind.DOG, SoundKind.CAT,
                SoundKind.BABY_CRY, SoundKind.KNOCK, SoundKind.SHOUT
            ),
            AppMode.HOME.sounds
        )
    }

    @Test
    fun noModeListsTheSameSoundTwice() {
        for (mode in AppMode.values()) {
            assertEquals("${mode.name} 에 중복된 소리", mode.sounds.size, mode.sounds.toSet().size)
        }
    }

    @Test
    fun detectedSounds_existInHomeMode() {
        // 감지 서비스는 홈 모드의 스위치를 따른다. 감지하는 두 소리가 홈 목록에 있어야 한다.
        assertEquals(true, SoundKind.DOORBELL in AppMode.HOME.sounds)
        assertEquals(true, SoundKind.BABY_CRY in AppMode.HOME.sounds)
    }

    @Test
    fun petAndKidAnswers_reachEveryModeThatHasThoseSwitches() {
        val petModes = AppMode.values().filter { m -> m.sounds.any { it == SoundKind.DOG || it == SoundKind.CAT } }
        val kidModes = AppMode.values().filter { SoundKind.BABY_CRY in it.sounds }
        assertEquals(setOf(AppMode.HOME, AppMode.DRIVING, AppMode.TRANSIT, AppMode.MYMENU), petModes.toSet())
        assertEquals(setOf(AppMode.HOME, AppMode.DRIVING, AppMode.TRANSIT, AppMode.MYMENU), kidModes.toSet())
    }

    @Test
    fun fromKey() {
        assertEquals(AppMode.TRANSIT, AppMode.fromKey("transit"))
        assertNotNull(AppMode.fromKey("home"))
        assertNull(AppMode.fromKey("nope"))
        assertNull(AppMode.fromKey(null))
    }
}
