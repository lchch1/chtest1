# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile
# --- Gson 으로 SharedPreferences 에 저장되는 모델: 난독화 시 필드명이 바뀌면 저장된 JSON 을 읽지 못한다 ---
-keep class com.example.yamnetwatchapp0913.ChatMessage { *; }
-keep class com.example.yamnetwatchapp0913.WordItem { *; }
-keep class com.example.yamnetwatchapp0913.AudioFileData { *; }
-keep class com.example.yamnetwatchapp0913.ConversationRecord { *; }
